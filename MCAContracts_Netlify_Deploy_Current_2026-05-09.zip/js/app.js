/* ============================================================================
 * app.js — MCA Contract Tool
 * ----------------------------------------------------------------------------
 * Pure client-side. Loads the master PDF + a JSON file of pre-extracted
 * {{placeholder}} coordinates, overlays merchant data on top, slices out
 * the funder's page range, separates the Written Consent into its own PDF,
 * and conditionally drops Schedule A pages.
 *
 * Architecture:
 *   1. master/Revised_Template_PDF.pdf and master/placeholder_coords.json
 *      are loaded once at startup, kept in memory.
 *   2. PDF.js extracts each page's text (with placeholders intact) so we
 *      can locate Written Consent and Schedule A pages by content fingerprint.
 *   3. On generate:
 *      a. Load master bytes into a fresh pdf-lib PDFDocument.
 *      b. For each placeholder coord on each page: white-rect the original
 *         {{...}} text and drawText() the replacement value at the same
 *         baseline. Auto-shrink to fit available width (min 8pt).
 *      c. Find Written Consent and Schedule A pages by content fingerprint.
 *      d. Build main PDF: copy funder's range, skip WC, skip SA if no
 *         co-entities filled.
 *      e. Build Written Consent PDF: just the WC page.
 *      f. Trigger downloads of both files.
 * ==========================================================================*/

(function () {
  'use strict';

  const $  = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const cfg = window.MCA_CONFIG;

  pdfjsLib.GlobalWorkerOptions.workerSrc = 'js/pdf.worker.min.js';
  const { PDFDocument } = PDFLib;

  /* ========================================================================
   * STATE
   * ======================================================================*/
  const STATE = {
    masterBytes: null,        // ArrayBuffer of Revised_Template_PDF_clean.pdf
    introFormBytes: null,     // ArrayBuffer of Revenue_Confidence_Form.pdf
    pageTextCache: null,      // Map<pageIdx (1-indexed), normalized lowercase text>
    coordsByPage: null,       // Map<pageIdx (1-indexed), Array<{name,x,y_bot,...}>>
    compositeSlotsByPage: null,  // Map<pageIdx (1-indexed), Array<composite slot>> (v9)
    currentFunder: 'ESE',
  };

  /* ========================================================================
   * DRAFT / AUTOSAVE
   * ======================================================================*/
  const STORAGE_KEY_AUTOSAVE = 'mca_tool_autosave_v1';
  const STORAGE_KEY_DRAFTS   = 'mca_tool_drafts_v1';

  function readForm() {
    const data = { funder: STATE.currentFunder };
    $$('input[data-field], select[data-field]').forEach(el => {
      if (el.type === 'checkbox') {
        data[el.dataset.field] = el.checked;
      } else {
        data[el.dataset.field] = el.value;
      }
    });
    return data;
  }

  function writeForm(data) {
    if (!data) return;
    if (data.funder && cfg.FUNDERS[data.funder]) {
      STATE.currentFunder = data.funder;
      $('#funder-select').value = data.funder;
      $('#funder-label').textContent = cfg.FUNDERS[data.funder].label;
    }
    $$('input[data-field], select[data-field]').forEach(el => {
      const v = data[el.dataset.field];
      if (el.type === 'checkbox') {
        el.checked = !!v;
      } else {
        el.value = v == null ? '' : v;
      }
    });
  }

  function autosave() {
    try {
      localStorage.setItem(STORAGE_KEY_AUTOSAVE, JSON.stringify(readForm()));
    } catch (e) { /* private mode etc. */ }
  }

  function restoreAutosave() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_AUTOSAVE);
      if (raw) writeForm(JSON.parse(raw));
    } catch (e) { /* ignore */ }
  }

  function listDrafts() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY_DRAFTS) || '{}'); }
    catch (e) { return {}; }
  }

  function saveDraft(name) {
    try {
      const drafts = listDrafts();
      drafts[name] = { ...readForm(), _savedAt: new Date().toISOString() };
      localStorage.setItem(STORAGE_KEY_DRAFTS, JSON.stringify(drafts));
      refreshDraftList();
    } catch (e) {
      flashStatus(`Could not save draft (browser storage error): ${e.message}`, 'err');
    }
  }

  function loadDraft(name) {
    const drafts = listDrafts();
    if (drafts[name]) {
      writeForm(drafts[name]);
      autosave();
      flashStatus(`Loaded draft "${name}".`);
    }
  }

  function deleteDraft(name) {
    try {
      const drafts = listDrafts();
      delete drafts[name];
      localStorage.setItem(STORAGE_KEY_DRAFTS, JSON.stringify(drafts));
      refreshDraftList();
    } catch (e) {
      flashStatus(`Could not delete draft (browser storage error): ${e.message}`, 'err');
    }
  }

  function refreshDraftList() {
    const sel = $('#draft-load-select');
    const names = Object.keys(listDrafts()).sort();
    sel.innerHTML = '<option value="">— Load draft —</option>' +
      names.map(n => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join('');
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  /* ========================================================================
   * FORM RENDERING
   * ======================================================================*/
  function renderForm() {
    const funderSelect = $('#funder-select');
    funderSelect.innerHTML = Object.values(cfg.FUNDERS)
      .map(f => `<option value="${f.code}">${escapeHtml(f.code)} — ${escapeHtml(f.label)}</option>`)
      .join('');
    funderSelect.value = STATE.currentFunder;
    $('#funder-label').textContent = cfg.FUNDERS[STATE.currentFunder].label;

    const sectionsHost = $('#form-sections');
    sectionsHost.innerHTML = '';
    cfg.FORM_SECTIONS.forEach(section => {
      const sec = document.createElement('section');
      sec.className = 'form-section';
      sec.innerHTML = `<h3>${escapeHtml(section.title)}</h3>`;
      const grid = document.createElement('div');
      grid.className = 'field-grid';
      section.fields.forEach(f => grid.appendChild(makeField(f)));
      sec.appendChild(grid);
      sectionsHost.appendChild(sec);
    });

    const saHost = $('#schedule-a-host');
    saHost.innerHTML = `
      <h3>Schedule A — Co-Applicant Entities</h3>
      <p class="hint">Use one row per additional entity. Put the primary Seller EIN in the Identity section, and put each additional entity EIN in its own Schedule A row when available.
      If all three entity rows are blank, Schedule A is removed entirely.</p>
    `;
    cfg.SCHEDULE_A_FIELDS.forEach(({ suffix, label }) => {
      const block = document.createElement('div');
      block.className = 'sched-a-block';
      block.innerHTML = `<h4>${escapeHtml(label)}</h4><div class="field-grid"></div>`;
      const grid = block.querySelector('.field-grid');
      grid.appendChild(makeField({ id: `biz_${suffix}`,     label: 'Entity Name',    type: 'text', placeholder: '(optional)' }));
      grid.appendChild(makeField({ id: `ein_${suffix}`,     label: 'Entity EIN',     type: 'text', placeholder: '12-3456789 (optional)' }));
      grid.appendChild(makeField({ id: `es_${suffix}`,      label: 'State',          type: 'text', placeholder: 'NY' }));
      grid.appendChild(makeField({ id: `address_${suffix}`, label: 'Entity Address', type: 'text', placeholder: '(optional)' }));
      saHost.appendChild(block);
    });

    $$('input[data-field], select[data-field]').forEach(el => {
      el.addEventListener('input', autosave);
      el.addEventListener('change', autosave);
    });
  }

  function makeField(f) {
    const wrap = document.createElement('div');
    wrap.className = 'field';
    const reqMark = f.required ? '<span class="req">*</span>' : '';
    let control;
    if (f.type === 'select') {
      control = document.createElement('select');
      control.innerHTML = '<option value="">—</option>' +
        f.options.map(o => `<option value="${escapeHtml(o)}">${escapeHtml(o)}</option>`).join('');
    } else if (f.type === 'checkbox') {
      control = document.createElement('input');
      control.type = 'checkbox';
    } else {
      control = document.createElement('input');
      control.type = f.type === 'date' ? 'date' : 'text';
      if (f.placeholder) control.placeholder = f.placeholder;
    }
    control.dataset.field = f.id;
    control.id = `field-${f.id}`;
    if (f.required) control.dataset.required = 'true';

    wrap.innerHTML = `<label for="field-${f.id}">${escapeHtml(f.label)}${reqMark}</label>`;
    wrap.appendChild(control);
    if (f.helpText) {
      const help = document.createElement('div');
      help.className = 'field-help';
      help.textContent = f.helpText;
      wrap.appendChild(help);
    }
    return wrap;
  }

  /* ========================================================================
   * MASTER PDF — load once, build text cache + load coord index
   * ======================================================================*/
  async function loadMasterIfNeeded() {
    if (STATE.masterBytes && STATE.pageTextCache && STATE.coordsByPage && STATE.compositeSlotsByPage && STATE.introFormBytes) return;
    setBusy('Loading master template...');
    const [pdfResp, coordsResp, introResp] = await Promise.all([
      fetch(cfg.masterPdfUrl),
      fetch(cfg.coordsJsonUrl),
      fetch(cfg.introFormUrl),
    ]);
    if (!pdfResp.ok)    throw new Error(`Failed to load master: HTTP ${pdfResp.status}`);
    if (!coordsResp.ok) throw new Error(`Failed to load coords: HTTP ${coordsResp.status}`);
    if (!introResp.ok)  throw new Error(`Failed to load intro form: HTTP ${introResp.status}`);
    STATE.masterBytes    = await pdfResp.arrayBuffer();
    STATE.introFormBytes = await introResp.arrayBuffer();
    const coordsJson = await coordsResp.json();
    // Convert keys (string from JSON) to numbers for easier lookup
    const map = new Map();
    for (const [k, v] of Object.entries(coordsJson.placeholders_by_page)) {
      map.set(parseInt(k, 10), v);
    }
    STATE.coordsByPage = map;
    // v9: composite slots
    const slotMap = new Map();
    const compRaw = coordsJson.composite_slots_by_page || {};
    for (const [k, v] of Object.entries(compRaw)) {
      slotMap.set(parseInt(k, 10), v);
    }
    STATE.compositeSlotsByPage = slotMap;

    setBusy('Indexing template text (one-time)...');
    await buildTextCache();
    setBusy('');
  }

  /**
   * Use PDF.js to extract per-page text — used ONLY for finding Written
   * Consent and Schedule A pages by content fingerprint.
   */
  async function buildTextCache() {
    const pdf = await pdfjsLib.getDocument({
      data: STATE.masterBytes.slice(0),
      disableFontFace: true,
    }).promise;
    const cache = new Map();
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const tc = await page.getTextContent();
      const flat = tc.items.map(it => it.str).join(' ');
      const normalized = flat
        .replace(/\{\{[^}]+\}\}/g, ' ')
        .toLowerCase()
        .replace(/\s+/g, ' ')
        .trim();
      cache.set(p, normalized);
    }
    pdf.cleanup();
    STATE.pageTextCache = cache;
  }

  /* ========================================================================
   * SECTION DETECTION HELPERS
   * Used by the verify* functions to confirm Schedule A and Written Consent
   * page contents match the expected fingerprints. The actual page numbers
   * come from the funder manifest (template-config.js).
   * ======================================================================*/
  function pageMatchesAll(text, terms) { return terms.every(t => text.includes(t.toLowerCase())); }
  function pageMatchesAny(text, terms) { return terms.some(t => text.includes(t.toLowerCase())); }

  /* ========================================================================
   * VALIDATION + GENERATION
   * ======================================================================*/
  function validateRequired(values) {
    const missing = [];
    for (const fid of cfg.REQUIRED_FIELDS) {
      const v = values[fid];
      if (!v || !String(v).trim()) missing.push(fid);
    }
    return missing;
  }

  /**
   * Validate field formats. Returns array of {field, label, expected} for any
   * fields whose value doesn't match its FIELD_FORMATS pattern. Empty values
   * are allowed (the required-field check handles those separately).
   */
  function validateFormats(values) {
    const failures = [];
    if (!cfg.FIELD_FORMATS) return failures;
    for (const [fid, spec] of Object.entries(cfg.FIELD_FORMATS)) {
      const v = String(values[fid] || '').trim();
      if (!v) continue;  // blank handled by required check
      const re = new RegExp(spec.pattern);
      if (!re.test(v)) {
        // Look up the form label for a better error message
        let label = fid;
        for (const sec of cfg.FORM_SECTIONS) {
          for (const f of sec.fields) if (f.id === fid) label = f.label;
        }
        const schedEin = /^ein_(\d+)$/.exec(fid);
        if (schedEin) label = `Co-Applicant Entity ${schedEin[1]} EIN`;
        failures.push({ field: fid, label, value: v, expected: spec.label });
      }
    }
    return failures;
  }

  /**
   * Validate a single Schedule A row.
   * Returns one of:
   *   { state: 'empty' }                 — all fields blank
   *   { state: 'complete' }              — required fields filled, EIN optional
   *   { state: 'partial', missing: [..] } — row touched but required data missing
   */
  function validateScheduleARow(values, suffix) {
    const biz  = String(values[`biz_${suffix}`]     || '').trim();
    const ein  = String(values[`ein_${suffix}`]     || '').trim();
    const es   = String(values[`es_${suffix}`]      || '').trim();
    const addr = String(values[`address_${suffix}`] || '').trim();
    const filled = [biz, ein, es, addr].filter(Boolean).length;
    if (filled === 0) return { state: 'empty' };
    if (biz && es && addr) return { state: 'complete' };
    const missing = [];
    if (!biz)  missing.push(`Entity ${suffix} Business Name`);
    if (!es)   missing.push(`Entity ${suffix} State`);
    if (!addr) missing.push(`Entity ${suffix} Address`);
    return { state: 'partial', missing };
  }

  /**
   * Decide whether Schedule A pages should be INCLUDED in the contract.
   * Throws an error if any row is partially filled — this prevents silent
   * data loss when an operator types only part of a co-entity row.
   * Returns true if any row is fully complete; false if all rows are empty.
   */
  function shouldIncludeScheduleA(values) {
    const rows = ['1', '2', '3'].map(s => validateScheduleARow(values, s));
    const partial = rows.filter(r => r.state === 'partial');
    if (partial.length) {
      const allMissing = partial.flatMap(r => r.missing);
      throw new Error(
        'Schedule A rows have partial data. Either fill Business Name, State, and Address ' +
        'for each touched row (Entity EIN is optional), or clear the row ' +
        'completely.\n\nMissing:\n  • ' + allMissing.join('\n  • ')
      );
    }
    return rows.some(r => r.state === 'complete');
  }

  /**
   * Format date input (YYYY-MM-DD from <input type="date">) to "MM/DD/YY"
   * for display in the contract (matches the examples).
   */
  function formatDate(isoDate) {
    if (!isoDate) return '';
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(isoDate);
    if (!m) return isoDate;
    return `${m[2]}/${m[3]}/${m[1].slice(2)}`;
  }

  /**
   * Normalize and validate form values BEFORE generating placeholder values.
   *  - trims all string fields
   *  - falls back mailing_address to address when blank (the master uses
   *    {{mailing Address}} on the disclosure page; we don't want a blank)
   * Returns a NEW values object (does not mutate input).
   */
  function normalizeFormValues(raw) {
    const out = {};
    for (const [k, v] of Object.entries(raw)) {
      out[k] = (typeof v === 'string') ? v.trim() : v;
    }
    // Mailing address falls back to business address
    if (!out.mailing_address) {
      out.mailing_address = out.address || '';
    }
    // DBA: three valid states for an MCA contract:
    //   (a) Operator entered a DBA name -> use it
    //   (b) Operator checked "Merchant has no DBA" -> use legal business name
    //       (this is an explicit operator-affirmed factual representation)
    //   (c) Neither -> validation error (handled in generate())
    // We do NOT silently substitute. Auto-fabricating a DBA the merchant
    // didn't actually use creates exposure in UCC 9-406 collection actions
    // and notice litigation. The operator must affirm the no-DBA fact.
    if (!out.dba_name && out.no_dba) {
      out.dba_name = out.business_name || '';
    }
    return out;
  }

  /**
   * Build a flat dict mapping base placeholder name -> string value,
   * derived from form field values via FIELD_TO_PLACEHOLDERS.
   */
  function buildPlaceholderValues(formValues) {
    const out = {};
    for (const [field, placeholders] of Object.entries(cfg.FIELD_TO_PLACEHOLDERS)) {
      let v = formValues[field] != null ? String(formValues[field]) : '';
      // Apply field-specific formatting
      if (field === 'date') v = formatDate(v);
      for (const ph of placeholders) {
        out[ph] = v;
      }
    }
    return out;
  }

  function parseMoney(value) {
    const cleaned = String(value || '').replace(/[$,\s]/g, '');
    if (!cleaned) return NaN;
    const n = Number(cleaned);
    return Number.isFinite(n) ? n : NaN;
  }

  function formatMoneyFixed(value) {
    if (!Number.isFinite(value)) return '';
    return '$' + value.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  function formatEstimatedPayments(value) {
    if (!Number.isFinite(value)) return '';
    const rounded = Math.round(value * 100) / 100;
    if (Math.abs(rounded - Math.round(rounded)) < 0.005) {
      return String(Math.round(rounded));
    }
    return rounded.toLocaleString('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    });
  }

  function buildDerivedValues(formValues) {
    const payback = parseMoney(formValues.payback_amount);
    const netFunded = parseMoney(formValues.net_funded);
    const dailyPayment = parseMoney(formValues.daily_payment);
    return {
      disclosure_total_cost: (
        Number.isFinite(payback) && Number.isFinite(netFunded)
      ) ? formatMoneyFixed(payback - netFunded) : '',
      disclosure_estimated_payments: (
        Number.isFinite(payback) && Number.isFinite(dailyPayment) && dailyPayment !== 0
      ) ? formatEstimatedPayments(payback / dailyPayment) : '',
    };
  }

  const DISCLOSURE_DERIVED_FIELDS = {
    37: [
      { key: 'disclosure_total_cost', x: 342.22, y_bot: 337.49, baseline: 340.08, avail_w: 233.78, size: 12, font: 'TimesRoman' },
      { key: 'disclosure_estimated_payments', x: 342.22, y_bot: 276.14, baseline: 278.73, avail_w: 233.78, size: 12, font: 'TimesRoman' },
    ],
    90: [
      { key: 'disclosure_total_cost', x: 342.22, y_bot: 337.49, baseline: 340.08, avail_w: 233.78, size: 12, font: 'TimesRoman' },
      { key: 'disclosure_estimated_payments', x: 342.22, y_bot: 276.14, baseline: 278.73, avail_w: 233.78, size: 12, font: 'TimesRoman' },
    ],
    144: [
      { key: 'disclosure_total_cost', x: 342.22, y_bot: 337.49, baseline: 340.08, avail_w: 233.78, size: 12, font: 'TimesRoman' },
      { key: 'disclosure_estimated_payments', x: 342.22, y_bot: 276.14, baseline: 278.73, avail_w: 233.78, size: 12, font: 'TimesRoman' },
    ],
  };

  const ISO_OPENING_RECTS_BY_PAGE = {
    49: [
      { x0: 51.02, x1: 580, y0_pm: 188.88, y1_pm: 200.88 },
      { x0: 51.02, x1: 580, y0_pm: 202.88, y1_pm: 214.88 },
      { x0: 51.02, x1: 580, y0_pm: 216.88, y1_pm: 228.88 },
      { x0: 51.02, x1: 580, y0_pm: 230.88, y1_pm: 242.88 },
      { x0: 51.02, x1: 580, y0_pm: 244.88, y1_pm: 256.88 },
      { x0: 51.02, x1: 580, y0_pm: 258.88, y1_pm: 270.88 },
    ],
    102: [
      { x0: 51.02, x1: 580, y0_pm: 188.88, y1_pm: 200.88 },
      { x0: 51.02, x1: 580, y0_pm: 202.88, y1_pm: 214.88 },
      { x0: 51.02, x1: 580, y0_pm: 216.88, y1_pm: 228.88 },
      { x0: 51.02, x1: 580, y0_pm: 230.88, y1_pm: 242.88 },
      { x0: 51.02, x1: 580, y0_pm: 244.88, y1_pm: 256.88 },
      { x0: 51.02, x1: 580, y0_pm: 258.88, y1_pm: 270.88 },
    ],
    160: [
      { x0: 51.02, x1: 580, y0_pm: 188.88, y1_pm: 200.88 },
      { x0: 51.02, x1: 580, y0_pm: 202.88, y1_pm: 214.88 },
      { x0: 51.02, x1: 580, y0_pm: 216.88, y1_pm: 228.88 },
      { x0: 51.02, x1: 580, y0_pm: 230.88, y1_pm: 242.88 },
      { x0: 51.02, x1: 580, y0_pm: 244.88, y1_pm: 256.88 },
      { x0: 51.02, x1: 580, y0_pm: 258.88, y1_pm: 270.88 },
    ],
  };

  const PAGE_GROUPS = {
    ackOpening: [1, 54, 107],
    agreementSellerTable: [2, 55, 108],
    guarantyOpening: [17, 70, 123],
    securityTop: [21, 74, 127],
    powerOfAttorneyOpening: [28, 81, 134],
    powerOfAttorneyExecution: [29, 82, 135],
    noaAssignment: [33, 86, 140],
    declarationOpening: [35, 88, 142],
    disclosureRecipient: [37, 90, 144],
    consentOpening: [40, 93, 147],
    addendumOpening: [43, 96, 150],
    addendumExecution: [44, 97, 151],
    scheduleATitle: [45, 98, 152],
    scheduleAExecution: [46, 99, 153],
    isoOpening: [49, 102, 160],
    isoExecution: [53, 106, 164],
  };

  const FUNDER_LAYOUT_META = {
    ESE: {
      companyName: 'East Shore Equities, LLC',
      shortName: 'ESE',
      principalOffice: 'P.O. Box 18, Centereach, NY 11720',
      guarantyOffice: '5788 Merrick Rd STE 205, Massapequa, NY 11758',
      phoneNumber: '516-231-5595',
      submissionsEmail: 'submissions@EastShoreEquities.com',
      wcCompany: 'SMB CAPITAL MANAGEMENT FUND LP',
      wcSignerName: 'JONATHAN MENNA',
      wcSignerTitle: 'MANAGING MEMBER',
    },
    ICC: {
      companyName: 'Iron Crown Capital, LLC',
      shortName: 'ICC',
      principalOffice: 'P.O. Box 9, Centereach, NY 11720',
      guarantyOffice: '5788 Merrick Rd STE 205, Massapequa, NY 11758',
      phoneNumber: '516-231-5595',
      submissionsEmail: 'submissions@EastShoreEquities.com',
      wcCompany: '',
      wcSignerName: 'Rachele Puglisi',
      wcSignerTitle: '',
    },
    SMB: {
      companyName: 'East Shore Equities SMB, LLC',
      shortName: 'ESE',
      principalOffice: 'P.O. Box 18, Centereach, NY 11720',
      guarantyOffice: '5788 Merrick Rd STE 205, Massapequa, NY 11758',
      phoneNumber: '516-231-5595',
      submissionsEmail: 'submissions@EastShoreEquities.com',
      wcCompany: 'SMB CAPITAL MANAGEMENT FUND LP',
      wcSignerName: 'JONATHAN MENNA',
      wcSignerTitle: 'MANAGING MEMBER',
    },
  };

  /**
   * v9: COMPOSITE SLOT RENDERING
   *
   * A composite slot is a clause-level region where one or more {{...}}
   * placeholders are tightly glued to literal text (e.g. "{{biz}}, and each
   * additional entity listed in Schedule A..."). The master template author
   * laid these out so that the placeholder slot is sized for the {{...}}
   * token (~30pt wide), but real merchant values like "EAGLE7 HDD LLC"
   * (~75pt) overflow into the literal text and produce visual collisions.
   *
   * Composite-slot rendering re-flows the entire clause as one continuous
   * text block. It white-rects the original line rectangles (preserving
   * the exact wrap shape — never erasing literal text outside the clause),
   * then renders the substituted clause with auto-shrink and word wrap.
   *
   * For Seller-recital occurrences (where the literal text is ", and each
   * additional entity listed in Schedule A..."):
   *   - First try the SHORT FORM: "{{biz}} and {{owner}} DBA {{biz_or_dba}}"
   *     If it fits at the original size in the available width, use it.
   *   - Otherwise fall back to the LONG FORM (the original master clause text).
   *   - If NoSchedA is selected, never use the long form (always short or
   *     just {{biz}} alone).
   */

  // Anchor used to detect Seller-recital clauses (the trailing legal text we
  // would optionally drop or replace per Juan's rule).
  const SCHEDULE_A_RECITAL_RE = /\s*,?\s*and\s+each\s+additional\s+entity\s+listed\s+in\s+Schedule\s+A[^.]*?(?:incorporated\s+(?:herein\s+)?by\s+reference|by\s+reference)\s*\.?/i;

  function substitutePlaceholders(template, phValues) {
    return template.replace(/\{\{([^}]+)\}\}/g, (m, name) => {
      const v = phValues[name];
      return (v != null) ? String(v) : '';
    });
  }

  function normalizeComparableName(name) {
    return String(name || '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();
  }

  function isSameNamedPerson(nameA, nameB) {
    const a = normalizeComparableName(nameA);
    const b = normalizeComparableName(nameB);
    return !!a && !!b && a === b;
  }

  function getDistinctOwnerPair(owner1, owner2) {
    const primary = String(owner1 || '').trim();
    const secondary = String(owner2 || '').trim();
    if (primary && secondary && isSameNamedPerson(primary, secondary)) {
      return { primary, secondary: '' };
    }
    return { primary, secondary };
  }

  function hasDistinctSecondOwner(formValues) {
    const { secondary } = getDistinctOwnerPair(formValues.owner_1, formValues.owner_2);
    return !!secondary;
  }

  function joinOwners(owner1, owner2, conjunction = 'and') {
    const { primary, secondary } = getDistinctOwnerPair(owner1, owner2);
    if (primary && secondary) return `${primary} ${conjunction} ${secondary}`;
    return primary || secondary;
  }

  function joinOwnersWithTrailing(owner1, owner2, conjunction = 'and') {
    const { primary, secondary } = getDistinctOwnerPair(owner1, owner2);
    if (primary && secondary) return `${primary} ${conjunction} ${secondary}`;
    if (primary) return `${primary} ${conjunction}`;
    return secondary;
  }

  function buildSellerShortText(formValues) {
    const biz = String(formValues.business_name || '').trim();
    const dba = getResolvedDba(formValues);
    const owners = joinOwners(formValues.owner_1, formValues.owner_2, 'and');
    if (!biz) return owners ? `${owners} DBA ${dba}`.trim() : dba;
    if (!owners) return biz;
    return `${biz} and ${owners} DBA ${dba}`.trim();
  }

  /**
   * Wrap text into lines that each fit within `widthLimit` at `size` points.
   * Returns array of lines (strings).
   */
  function wrapToWidth(text, font, size, widthLimit) {
    const words = text.split(/\s+/).filter(w => w.length > 0);
    if (words.length === 0) return [''];
    const lines = [];
    let cur = words[0];
    for (let i = 1; i < words.length; i++) {
      const trial = cur + ' ' + words[i];
      if (font.widthOfTextAtSize(trial, size) <= widthLimit) {
        cur = trial;
      } else {
        lines.push(cur);
        cur = words[i];
      }
    }
    lines.push(cur);
    return lines;
  }

  /**
   * Pick the largest font size <= startSize that fits `text` within the
   * available line_rects of a composite slot. Uses word-wrap. Returns
   * { size, lines: [str], lineHeight }.
   */
  function fitTextToSlot(text, font, startSize, lineRects, minSize) {
    // Use the median width of available rects as the wrap width
    const rectWidths = lineRects.map(r => r.x1 - r.x0);
    rectWidths.sort((a, b) => a - b);
    const wrapWidth = rectWidths[Math.floor(rectWidths.length / 2)];
    let size = startSize;
    while (size >= minSize) {
      const lines = wrapToWidth(text, font, size, wrapWidth);
      if (lines.length <= lineRects.length) {
        // All lines also need to actually fit each rect's width
        let allFit = true;
        for (let i = 0; i < lines.length; i++) {
          const w = font.widthOfTextAtSize(lines[i], size);
          if (w > lineRects[i].x1 - lineRects[i].x0 + 0.5) {
            allFit = false;
            break;
          }
        }
        if (allFit) {
          // Approximate line height: 1.15 * font size
          return { size, lines, lineHeight: size * 1.15, fit: true };
        }
      }
      size -= 0.25;
    }
    // Couldn't fit — return at minSize with as many lines as needed (overflow)
    const lines = wrapToWidth(text, font, minSize, wrapWidth);
    return { size: minSize, lines, lineHeight: minSize * 1.15, fit: false };
  }

  function fitWrappedTextToBox(text, font, width, height, opts = {}) {
    const startSize = opts.startSize ?? 10;
    const minSize = opts.minSize ?? 6.5;
    const leadingFactor = opts.leadingFactor ?? 1.2;
    const maxLines = opts.maxLines ?? null;
    let size = startSize;
    while (size >= minSize) {
      const lines = wrapToWidth(String(text || ''), font, size, width);
      const leading = size * leadingFactor;
      const totalHeight = lines.length * leading;
      if ((!maxLines || lines.length <= maxLines) && totalHeight <= height + 0.5) {
        return { size, lines, leading, fit: true };
      }
      size -= 0.25;
    }
    const lines = wrapToWidth(String(text || ''), font, minSize, width);
    return { size: minSize, lines, leading: minSize * leadingFactor, fit: false };
  }

  function layoutRichText(spans, fontMap, size, lineRects) {
    const tokens = [];
    spans.forEach(span => {
      const parts = span.text.match(/\S+\s*/g) || [];
      parts.forEach(part => {
        tokens.push({ text: part, font: fontMap[span.font] || fontMap.TimesRoman });
      });
    });
    const lines = [];
    let lineIndex = 0;
    let x = lineRects[0].x0;
    let current = [];
    const flush = () => {
      lines.push(current);
      current = [];
      lineIndex += 1;
      if (lineIndex >= lineRects.length) return false;
      x = lineRects[lineIndex].x0;
      return true;
    };
    for (const token of tokens) {
      if (lineIndex >= lineRects.length) break;
      const rect = lineRects[lineIndex];
      const width = token.font.widthOfTextAtSize(token.text, size);
      if (current.length && x + width > rect.x1 + 0.5) {
        if (!flush()) break;
      }
      current.push({ ...token, x });
      x += width;
    }
    if (current.length && lineIndex < lineRects.length) lines.push(current);
    return lines;
  }

  function expandedLineRects(slot) {
    const rects = (slot.line_rects || []).map(r => ({ ...r }));
    if (!rects.length) return rects;
    const minX = Math.min(slot.bbox?.x0 ?? rects[0].x0, ...rects.map(r => r.x0));
    const maxX = Math.max(slot.bbox?.x1 ?? rects[0].x1, ...rects.map(r => r.x1));
    return rects.map(r => ({ ...r, x0: minX, x1: maxX }));
  }

  const CANONICAL_BASE_PAGE_OVERRIDES = new Map([
    [58, 5], [111, 5],
    [69, 16], [122, 16],
    [73, 20], [126, 20],
    [80, 27], [133, 27],
    [84, 31], [137, 31],
    [85, 32], [138, 32],
    [88, 35], [142, 35],
    [90, 37], [144, 37],
    [145, 38],
    [146, 39],
    [147, 40],
    [94, 41], [148, 41],
    [95, 42], [149, 42],
    [106, 53], [164, 53],
  ]);

  function getBasePageNum(pageNum) {
    if (CANONICAL_BASE_PAGE_OVERRIDES.has(pageNum)) {
      return CANONICAL_BASE_PAGE_OVERRIDES.get(pageNum);
    }
    if (pageNum >= 107) return pageNum - 106;
    if (pageNum >= 54) return pageNum - 53;
    return pageNum;
  }

  const FULL_CUSTOM_PAGES = new Set([
    28, 31, 32, 33, 34, 35, 37, 39, 41, 42, 46, 53,
    81, 84, 85, 86, 87, 88, 90, 92, 94, 95, 99, 106,
    134, 137, 138, 140, 141, 142, 144, 146, 148, 149, 153, 164,
  ]);
  const WRITTEN_CONSENT_PAGE_SET = new Set(
    Object.values(cfg.FUNDERS).flatMap(f => (f.separatePages && f.separatePages.writtenConsent) || [])
  );

  function isFullCustomPage(pageNum) {
    return FULL_CUSTOM_PAGES.has(pageNum) || WRITTEN_CONSENT_PAGE_SET.has(pageNum);
  }

  function pageIsInGroup(pageNum, groupName) {
    return (PAGE_GROUPS[groupName] || []).includes(pageNum);
  }

  function getLayoutMeta(funderCode) {
    return FUNDER_LAYOUT_META[funderCode] || FUNDER_LAYOUT_META.ESE;
  }

  function getResolvedDba(formValues) {
    return (formValues.dba_name || formValues.business_name || '').trim();
  }

  function getScheduleASuffix(includeSchedA) {
    return includeSchedA
      ? ', and each additional entity listed in Schedule A attached hereto and incorporated herein by reference'
      : '';
  }

  function getBizSlotText(formValues, includeSchedA) {
    const biz = (formValues.business_name || '').trim();
    const owner = (formValues.owner_1 || '').trim();
    const dba = getResolvedDba(formValues);
    if (!biz) return '';
    if (includeSchedA) return `${biz}${getScheduleASuffix(true)}`;
    return `${biz} and ${owner} DBA ${dba}`.trim();
  }

  function getDbaSlotText(formValues, includeSchedA) {
    const dba = getResolvedDba(formValues);
    if (!dba) return '';
    return includeSchedA ? `${dba}${getScheduleASuffix(true)}` : dba;
  }

  function getOwnerClauseText(formValues) {
    return joinOwnersWithTrailing(formValues.owner_1, formValues.owner_2, 'and');
  }

  function getOwnerAmpClauseText(formValues) {
    return joinOwnersWithTrailing(formValues.owner_1, formValues.owner_2, '&');
  }

  function getOwnerDisplayListText(formValues) {
    return joinOwners(formValues.owner_1, formValues.owner_2, 'and');
  }

  function getOwnerAmpDisplayText(formValues) {
    return joinOwners(formValues.owner_1, formValues.owner_2, '&');
  }

  function getOwnerDisplayText(formValues, ownerIndex) {
    const { primary, secondary } = getDistinctOwnerPair(formValues.owner_1, formValues.owner_2);
    if (ownerIndex === 2) return secondary;
    return primary;
  }

  function getSsnClauseText(formValues) {
    const ssn1 = (formValues.ssn_1 || '').trim();
    const ssn2 = (formValues.ssn_2 || '').trim();
    if (!hasDistinctSecondOwner(formValues)) return ssn1 || ssn2 || '';
    return ssn1 && ssn2 ? `${ssn1} / ${ssn2}` : (ssn1 || ssn2);
  }

  function getSsnDisplayText(formValues, ownerIndex) {
    if (ownerIndex === 2) return hasDistinctSecondOwner(formValues) ? (formValues.ssn_2 || '').trim() : '';
    return (formValues.ssn_1 || '').trim();
  }

  function getSignerTitle(formValues, ownerIndex) {
    const owner = getOwnerDisplayText(formValues, ownerIndex);
    return owner ? `${owner}/Owner` : '';
  }

  function getSellerSignatureText(formValues, includeSchedA) {
    return includeSchedA ? getBizSlotText(formValues, true) : buildSellerShortText(formValues);
  }

  function clearRectTop(page, pageHeight, x, yTop, width, height, pad = 1.5) {
    page.drawRectangle({
      x: x - pad,
      y: pageHeight - (yTop + height) - pad,
      width: width + (pad * 2),
      height: height + (pad * 2),
      color: PDFLib.rgb(1, 1, 1),
      borderWidth: 0,
    });
  }

  function drawTopText(page, pageHeight, text, x, yTop, size, font) {
    page.drawText(String(text || ''), {
      x,
      y: pageHeight - yTop - size,
      size,
      font,
      color: PDFLib.rgb(0, 0, 0),
    });
  }

  function drawTopRule(page, pageHeight, x, yTop, width, thickness = 0.75) {
    const y = pageHeight - yTop;
    page.drawLine({
      start: { x, y },
      end: { x: x + width, y },
      thickness,
      color: PDFLib.rgb(0, 0, 0),
    });
  }

  function drawWrappedBlock(page, pageHeight, text, x, yTop, width, font, size, leading = null) {
    const lineGap = leading || (size * 1.25);
    let y = yTop;
    const paras = String(text || '').split(/\n+/);
    paras.forEach((para, idx) => {
      const lines = wrapToWidth(para.trim(), font, size, width);
      lines.forEach(line => {
        drawTopText(page, pageHeight, line, x, y, size, font);
        y += lineGap;
      });
      if (idx < paras.length - 1) y += size * 0.35;
    });
    return y;
  }

  function drawFittedWrappedBlock(page, pageHeight, text, x, yTop, width, height, font, opts = {}) {
    const fitted = fitWrappedTextToBox(text, font, width, height, opts);
    let y = yTop;
    fitted.lines.forEach(line => {
      drawTopText(page, pageHeight, line, x, y, fitted.size, font);
      y += fitted.leading;
    });
    return { ...fitted, nextY: y };
  }

  function drawBulletList(page, pageHeight, items, x, yTop, width, font, size, opts = {}) {
    const bulletFont = opts.bulletFont || font;
    const indent = opts.indent || 15;
    const leading = opts.leading || (size * 1.25);
    const paraGap = opts.paraGap || (size * 0.35);
    let y = yTop;
    (items || []).forEach(item => {
      const lines = wrapToWidth(String(item || '').trim(), font, size, Math.max(width - indent, 40));
      lines.forEach((line, idx) => {
        if (idx === 0) {
          drawTopText(page, pageHeight, '•', x, y, size, bulletFont);
        }
        drawTopText(page, pageHeight, line, x + indent, y, size, font);
        y += leading;
      });
      y += paraGap;
    });
    return y;
  }

  function drawFieldStack(page, pageHeight, label, value, x, yTop, width, fonts, opts = {}) {
    const labelFont = opts.labelFont || fonts.TimesBold || fonts.HelveticaBold;
    const valueFont = opts.valueFont || fonts.TimesRoman || fonts.Helvetica;
    const labelSize = opts.labelSize || 10;
    const valueSize = opts.valueSize || 12;
    const labelGap = opts.labelGap || 14;
    const valueLeading = opts.valueLeading || (valueSize * 1.18);
    drawTopText(page, pageHeight, label, x, yTop, labelSize, labelFont);
    return drawWrappedBlock(page, pageHeight, value || '', x, yTop + labelGap, width, valueFont, valueSize, valueLeading);
  }

  function drawInlineField(page, pageHeight, label, value, x, yTop, width, fonts, opts = {}) {
    const labelFont = opts.labelFont || fonts.TimesBold || fonts.HelveticaBold;
    const valueFont = opts.valueFont || fonts.TimesRoman || fonts.Helvetica;
    const labelSize = opts.labelSize || 10.5;
    const valueSize = opts.valueSize || labelSize;
    const gap = opts.gap || 6;
    const valueLeading = opts.valueLeading || (valueSize * 1.2);
    drawTopText(page, pageHeight, label, x, yTop, labelSize, labelFont);
    const labelWidth = labelFont.widthOfTextAtSize(label, labelSize);
    const valueX = x + labelWidth + gap;
    return drawWrappedBlock(
      page,
      pageHeight,
      value || '',
      valueX,
      yTop,
      Math.max(width - (valueX - x), 40),
      valueFont,
      valueSize,
      valueLeading
    );
  }

  function clearRegionTop(page, pageHeight, region, pad = 2) {
    clearRectTop(page, pageHeight, region.x, region.yTop, region.width, region.height, pad);
  }

  function drawTopVerticalRule(page, pageHeight, x, yTop, height, thickness = 0.75) {
    page.drawLine({
      start: { x, y: pageHeight - yTop },
      end: { x, y: pageHeight - (yTop + height) },
      thickness,
      color: PDFLib.rgb(0, 0, 0),
    });
  }

  function drawCenteredTopText(page, pageHeight, text, centerX, yTop, size, font) {
    const safeText = String(text || '');
    const width = font.widthOfTextAtSize(safeText, size);
    drawTopText(page, pageHeight, safeText, centerX - (width / 2), yTop, size, font);
  }

  function drawInitialsFooter(page, pageHeight, fonts, opts = {}) {
    const x = opts.x ?? 468;
    const yTop = opts.yTop ?? 756;
    const label = opts.label || 'Initials:';
    const labelFont = opts.labelFont || fonts.TimesBold || fonts.HelveticaBold;
    const labelSize = opts.labelSize || 9.75;
    drawTopText(page, pageHeight, label, x, yTop, labelSize, labelFont);
    const labelWidth = labelFont.widthOfTextAtSize(label, labelSize);
    drawTopRule(page, pageHeight, x + labelWidth + 8, yTop + 10, opts.lineWidth || 44, 0.8);
  }

  function topPointInRegion(x, yTop, region, pad = 0) {
    return (
      x >= region.x - pad &&
      x <= region.x + region.width + pad &&
      yTop >= region.yTop - pad &&
      yTop <= region.yTop + region.height + pad
    );
  }

  function topRegionsIntersect(a, b, pad = 0) {
    return !(
      a.x + a.width < b.x - pad ||
      b.x + b.width < a.x - pad ||
      a.yTop + a.height < b.yTop - pad ||
      b.yTop + b.height < a.yTop - pad
    );
  }

  function slotToTopRegion(slot) {
    const rects = slot?.line_rects || [];
    if (!rects.length) return null;
    const x0 = Math.min(...rects.map(r => r.x0));
    const x1 = Math.max(...rects.map(r => r.x1));
    const y0 = Math.min(...rects.map(r => r.y0_pm));
    const y1 = Math.max(...rects.map(r => r.y1_pm));
    return { x: x0, yTop: y0, width: x1 - x0, height: y1 - y0 };
  }

  function getCustomOverrideRegions(pageNum) {
    const basePage = getBasePageNum(pageNum);
    const regions = [];

    if (basePage === 5) {
      regions.push({ x: 44, yTop: 112, width: 536, height: 500 });
    }

    if (basePage === 16) {
      regions.push({ x: 44, yTop: 178, width: 536, height: 438 });
    }

    if (basePage === 20) {
      regions.push({ x: 46, yTop: 110, width: 534, height: 390 });
    }

    if (basePage === 27) {
      regions.push({ x: 46, yTop: 162, width: 534, height: 374 });
    }

    if (basePage === 31) {
      regions.push({ x: 44, yTop: 34, width: 540, height: 700 });
    }

    if (basePage === 32) {
      regions.push({ x: 44, yTop: 34, width: 540, height: 700 });
    }

    if (basePage === 35) {
      regions.push({ x: 44, yTop: 34, width: 540, height: 700 });
    }

    if (basePage === 37) {
      regions.push({ x: 338, yTop: 92, width: 240, height: 178 });
    }

    if (basePage === 38) {
      regions.push({ x: 52, yTop: 604, width: 508, height: 130 });
    }

    if (basePage === 39) {
      regions.push({ x: 44, yTop: 34, width: 540, height: 700 });
    }

    if (basePage === 41) {
      regions.push({ x: 44, yTop: 34, width: 540, height: 700 });
    }

    if (basePage === 42) {
      regions.push({ x: 44, yTop: 34, width: 540, height: 700 });
    }

    if (basePage === 53) {
      regions.push({ x: 44, yTop: 34, width: 540, height: 700 });
    }

    if (pageIsInGroup(pageNum, 'ackOpening')) {
      regions.push({ x: 44, yTop: 54, width: 536, height: 678 });
    }

    if (pageIsInGroup(pageNum, 'agreementSellerTable')) {
      regions.push({ x: 42, yTop: 124, width: 540, height: 222 });
    }

    if (pageIsInGroup(pageNum, 'guarantyOpening')) {
      regions.push({ x: 46, yTop: 62, width: 534, height: 110 });
    }

    if (pageIsInGroup(pageNum, 'securityTop')) {
      regions.push({ x: 46, yTop: 58, width: 534, height: 198 });
    }

    if (pageIsInGroup(pageNum, 'powerOfAttorneyOpening')) {
      regions.push({ x: 38, yTop: 34, width: 556, height: 700 });
    }

    if (pageIsInGroup(pageNum, 'powerOfAttorneyExecution')) {
      regions.push({ x: 46, yTop: 116, width: 534, height: 210 });
    }

    if (pageIsInGroup(pageNum, 'noaAssignment')) {
      regions.push({ x: 42, yTop: 72, width: 540, height: 144 });
      regions.push({ x: 42, yTop: 470, width: 540, height: 278 });
    }

    if (pageIsInGroup(pageNum, 'declarationOpening')) {
      regions.push({ x: 44, yTop: 72, width: 538, height: 108 });
    }

    if (pageIsInGroup(pageNum, 'addendumOpening')) {
      regions.push({ x: 44, yTop: 58, width: 536, height: 110 });
    }

    if (pageIsInGroup(pageNum, 'addendumExecution')) {
      regions.push({ x: 52, yTop: 152, width: 508, height: 308 });
    }

    if (pageIsInGroup(pageNum, 'scheduleAExecution')) {
      regions.push({ x: 38, yTop: 166, width: 548, height: 558 });
    }

    if (pageIsInGroup(pageNum, 'isoOpening')) {
      const rects = ISO_OPENING_RECTS_BY_PAGE[pageNum] || [];
      if (rects.length) {
        const x0 = Math.min(...rects.map(r => r.x0));
        const x1 = Math.max(...rects.map(r => r.x1));
        const y0 = Math.min(...rects.map(r => r.y0_pm));
        const y1 = Math.max(...rects.map(r => r.y1_pm));
        regions.push({ x: x0, yTop: y0, width: x1 - x0, height: y1 - y0 });
      }
    }

    return regions;
  }

  function drawSignaturePanel(page, pageHeight, x, yTop, width, heading, nameTitle, ssn, fonts, opts = {}) {
    const headingFont = fonts.HelveticaBold;
    const textFont = fonts.Helvetica;
    const headingSize = opts.headingSize || 13;
    const bySize = opts.bySize || 11.5;
    const labelSize = opts.labelSize || 10.5;
    const nameSize = opts.nameSize || labelSize;
    const companyLabelSize = opts.companyLabelSize || labelSize;
    let y = yTop;
    if (heading) {
      drawTopText(page, pageHeight, heading, x, y, headingSize, headingFont);
      y += opts.headingGap || 20;
    }
    if (opts.subheading) {
      drawWrappedBlock(page, pageHeight, opts.subheading, x, y, width, fonts.TimesRoman, 10, 12);
      y += 24;
    }
    drawTopText(page, pageHeight, 'By:', x, y, bySize, headingFont);
    drawTopRule(page, pageHeight, x + 28, y + 11, width - 28, 0.9);
    y += opts.afterByGap || 20;
    drawTopText(page, pageHeight, 'Signature', x + 28, y, labelSize, textFont);
    y += opts.signatureGap || 20;
    drawTopText(page, pageHeight, 'Print Name and Title', x + 28, y, labelSize, textFont);
    y += opts.nameTopGap || 14;
    if (nameTitle) {
      y = drawWrappedBlock(page, pageHeight, nameTitle, x + 28, y, width - 28, textFont, nameSize, opts.nameLeading || (nameSize * 1.17));
    } else {
      y += 12;
    }
    drawTopText(page, pageHeight, 'SS#', x + 28, y + 2, labelSize, textFont);
    if (ssn) {
      drawWrappedBlock(page, pageHeight, ssn, x + 62, y, width - 62, textFont, labelSize, labelSize * 1.15);
    }
    y += opts.afterSsnGap || 24;
    if (opts.companyText) {
      y = drawWrappedBlock(
        page,
        pageHeight,
        opts.companyText,
        x + 28,
        y,
        width - 28,
        opts.companyFont || fonts.TimesRoman || textFont,
        opts.companySize || 9.75,
        opts.companyLeading || 11.25
      );
      y += 8;
      drawTopText(page, pageHeight, opts.companyLabel || 'Company', x + 28, y, companyLabelSize, textFont);
      y += 16;
    }
    return y;
  }

  function renderCustomPageOverrides(page, pageNum, formValues, fonts, includeSchedA, pageHeight) {
    const basePage = getBasePageNum(pageNum);
    const businessName = String(formValues.business_name || '').trim();
    const owner1Text = String(formValues.owner_1 || '').trim();
    const businessOnlyText = businessName;
    const dbaOnlyText = includeSchedA ? getDbaSlotText(formValues, true) : getResolvedDba(formValues);
    const sellerPartyText = includeSchedA ? getBizSlotText(formValues, true) : buildSellerShortText(formValues);
    const ownerText = getOwnerClauseText(formValues);
    const ownerAmpText = getOwnerAmpClauseText(formValues);
    const ownerDisplayText = getOwnerDisplayListText(formValues);
    const ownerAmpDisplayText = getOwnerAmpDisplayText(formValues);
    const ssnText = getSsnClauseText(formValues);
    const addressText = String(formValues.address || '').trim();
    const dateText = formatDate(formValues.date || '');
    const psfText = String(formValues.psf || '').trim();
    const layout = getLayoutMeta(formValues.funder);
    const hasSecondOwner = !!getOwnerDisplayText(formValues, 2);
    const writtenConsentPartyText = [
      ownerDisplayText,
      'Individually and on behalf of',
      businessOnlyText + ',',
      'and each additional entity listed in Schedule A attached hereto and incorporated herein by reference',
    ].filter(Boolean).join(' ');

    function renderSellerPanels(region, opts = {}) {
      clearRegionTop(page, pageHeight, region, 2.5);
      const leftHeading = opts.leftHeading ?? '';
      const rightHeading = opts.rightHeading ?? '';
      const leftNameTitle = getSignerTitle(formValues, 1);
      const leftSsn = getSsnDisplayText(formValues, 1);
      const rightNameTitle = getSignerTitle(formValues, 2);
      const rightSsn = getSsnDisplayText(formValues, 2);
      if (hasSecondOwner) {
        const gutter = opts.gutter || 32;
        const colWidth = (region.width - gutter) / 2;
        drawSignaturePanel(
          page, pageHeight, region.x, region.yTop, colWidth,
          leftHeading, leftNameTitle, leftSsn, fonts,
          {
            companyText: opts.companyText,
            companySize: opts.companySize,
            companyLeading: opts.companyLeading,
            companyFont: opts.companyFont,
            headingSize: opts.headingSize,
            headingGap: opts.headingGap,
            bySize: opts.bySize,
            labelSize: opts.labelSize,
            nameSize: opts.nameSize,
            nameLeading: opts.nameLeading,
            companyLabelSize: opts.companyLabelSize,
            afterByGap: opts.afterByGap,
            signatureGap: opts.signatureGap,
            nameTopGap: opts.nameTopGap,
            afterSsnGap: opts.afterSsnGap,
            subheading: opts.leftSubheading,
          }
        );
        drawSignaturePanel(
          page, pageHeight, region.x + colWidth + gutter, region.yTop, colWidth,
          rightHeading, rightNameTitle, rightSsn, fonts,
          {
            companyText: opts.companyText,
            companySize: opts.companySize,
            companyLeading: opts.companyLeading,
            companyFont: opts.companyFont,
            headingSize: opts.headingSize,
            headingGap: opts.headingGap,
            bySize: opts.bySize,
            labelSize: opts.labelSize,
            nameSize: opts.nameSize,
            nameLeading: opts.nameLeading,
            companyLabelSize: opts.companyLabelSize,
            afterByGap: opts.afterByGap,
            signatureGap: opts.signatureGap,
            nameTopGap: opts.nameTopGap,
            afterSsnGap: opts.afterSsnGap,
            subheading: opts.rightSubheading,
          }
        );
      } else {
        drawSignaturePanel(
          page, pageHeight, region.x, region.yTop, region.width,
          leftHeading, leftNameTitle, leftSsn, fonts,
          {
            companyText: opts.companyText,
            companySize: opts.companySize,
            companyLeading: opts.companyLeading,
            companyFont: opts.companyFont,
            headingSize: opts.headingSize,
            headingGap: opts.headingGap,
            bySize: opts.bySize,
            labelSize: opts.labelSize,
            nameSize: opts.nameSize,
            nameLeading: opts.nameLeading,
            companyLabelSize: opts.companyLabelSize,
            afterByGap: opts.afterByGap,
            signatureGap: opts.signatureGap,
            nameTopGap: opts.nameTopGap,
            afterSsnGap: opts.afterSsnGap,
            subheading: opts.leftSubheading,
          }
        );
      }
    }

    function renderOwnerPanels(region, opts = {}) {
      clearRegionTop(page, pageHeight, region, 2.5);
      const leftHeading = opts.leftHeading ?? 'OWNER/GUARANTOR #1';
      const rightHeading = opts.rightHeading ?? 'OWNER/GUARANTOR #2';
      const leftNameTitle = getSignerTitle(formValues, 1);
      const leftSsn = getSsnDisplayText(formValues, 1);
      const rightNameTitle = getSignerTitle(formValues, 2);
      const rightSsn = getSsnDisplayText(formValues, 2);
      if (hasSecondOwner) {
        const gutter = opts.gutter || 36;
        const colWidth = (region.width - gutter) / 2;
        drawSignaturePanel(page, pageHeight, region.x, region.yTop, colWidth, leftHeading, leftNameTitle, leftSsn, fonts, opts);
        drawSignaturePanel(page, pageHeight, region.x + colWidth + gutter, region.yTop, colWidth, rightHeading, rightNameTitle, rightSsn, fonts, opts);
      } else {
        drawSignaturePanel(page, pageHeight, region.x, region.yTop, region.width, leftHeading, leftNameTitle, leftSsn, fonts, opts);
      }
    }

    function renderDeclarationExecutionPanels(region, opts = {}) {
      const leftHeading = opts.leftHeading ?? 'FOR THE OWNER/SELLER (#1)';
      const rightHeading = opts.rightHeading ?? 'FOR THE OWNER/SELLER (#2)';
      const leftNameTitle = getOwnerDisplayText(formValues, 1);
      const rightNameTitle = getOwnerDisplayText(formValues, 2);

      const drawDeclarationPanel = (x, yTop, width, heading, nameTitle) => {
        let y = yTop;
        if (heading) {
          drawTopText(page, pageHeight, heading, x, y, 11.5, fonts.HelveticaBold);
          y += 26;
        }
        drawTopText(page, pageHeight, 'By:', x, y, 11, fonts.HelveticaBold);
        drawTopRule(page, pageHeight, x + 26, y + 10, width - 36, 0.8);
        y += 18;
        drawFittedWrappedBlock(page, pageHeight, nameTitle || '', x + 16, y, width - 18, 24, fonts.Helvetica, {
          startSize: 9.35,
          minSize: 7.25,
          leadingFactor: 1.08,
          maxLines: 2,
        });
        y += 28;
        drawTopText(page, pageHeight, '(Print Name and Title)', x + 16, y, 9.35, fonts.Helvetica);
        const sigLabel = '(Signature)';
        const sigWidth = fonts.Helvetica.widthOfTextAtSize(sigLabel, 9.35);
        drawTopText(page, pageHeight, sigLabel, x + width - sigWidth - 6, y, 9.35, fonts.Helvetica);
      };

      if (hasSecondOwner) {
        const gutter = opts.gutter || 36;
        const colWidth = (region.width - gutter) / 2;
        drawDeclarationPanel(region.x, region.yTop, colWidth, leftHeading, leftNameTitle);
        drawDeclarationPanel(region.x + colWidth + gutter, region.yTop, colWidth, rightHeading, rightNameTitle);
      } else {
        drawDeclarationPanel(region.x, region.yTop, region.width, leftHeading, leftNameTitle);
      }
    }

    function renderAdaptiveExecutionLayout() {
      return false;
    }

    if (WRITTEN_CONSENT_PAGE_SET.has(pageNum)) {
      let y = 78;
      drawCenteredTopText(page, pageHeight, 'Written Consent', page.getSize().width / 2, y, 18.5, fonts.TimesBold);
      y += 48;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'This letter serves as written authorization to enter into a merchant cash advance agreement with',
        44,
        y,
        514,
        fonts.TimesRoman,
        13.2,
        15.25
      );
      y += 6;
      drawFittedWrappedBlock(
        page,
        pageHeight,
        writtenConsentPartyText,
        52,
        y,
        500,
        42,
        fonts.Helvetica,
        { startSize: 9.15, minSize: 7.1, leadingFactor: 1.14, maxLines: 3 }
      );
      drawTopRule(page, pageHeight, 42, y + 46, 520, 0.8);
      y += 64;
      y = drawWrappedBlock(
        page,
        pageHeight,
        "I have reviewed the merchant’s bank statements, supporting documentation, and any other pertinent information regarding this transaction. I am willingly entering into this transaction and understand that there is potential to lose the entire sum of capital associated with this particular agreement, plus any applicable fees associated with this transaction.",
        44,
        y,
        514,
        fonts.TimesRoman,
        12.6,
        15.1
      );
      y += 52;
      drawTopText(page, pageHeight, 'Acknowledged & Agreed', 44, y, 12.6, fonts.TimesBold);
      y += 98;
      drawTopRule(page, pageHeight, 44, y, 250, 0.8);
      y += 10;
      const labelX = 44;
      const valueX = 118;
      const rowGap = 18;
      const labelFont = fonts.TimesRoman;
      const valueFont = fonts.Helvetica;
      drawTopText(page, pageHeight, 'Company:', labelX, y, 11.6, labelFont);
      if (layout.wcCompany) drawTopText(page, pageHeight, layout.wcCompany, valueX, y, 10.3, valueFont);
      y += rowGap;
      drawTopText(page, pageHeight, 'Name:', labelX, y, 11.6, labelFont);
      if (layout.wcSignerName) drawTopText(page, pageHeight, layout.wcSignerName, valueX, y, 10.3, valueFont);
      y += rowGap;
      drawTopText(page, pageHeight, 'Title:', labelX, y, 11.6, labelFont);
      if (layout.wcSignerTitle) drawTopText(page, pageHeight, layout.wcSignerTitle, valueX, y, 10.3, valueFont);
      y += rowGap;
      drawTopText(page, pageHeight, 'Date:', labelX, y, 11.6, labelFont);
      drawInitialsFooter(page, pageHeight, fonts);
      return;
    }

    if (basePage === 5) {
      clearRegionTop(page, pageHeight, { x: 44, yTop: 112, width: 536, height: 500 }, 3);
      renderSellerPanels(
        { x: 66, yTop: 246, width: 470, height: 130 },
        {
          leftHeading: 'SELLER #1',
          rightHeading: 'SELLER #2',
        }
      );
      renderOwnerPanels(
        { x: 66, yTop: 426, width: 470, height: 130 },
        {
          leftHeading: 'OWNER/GUARANTOR #1',
          rightHeading: 'OWNER/GUARANTOR #2',
        }
      );
      return;
    }

    if (basePage === 16) {
      clearRegionTop(page, pageHeight, { x: 44, yTop: 178, width: 536, height: 438 }, 3);
      renderSellerPanels(
        { x: 66, yTop: 258, width: 470, height: 130 },
        {
          leftHeading: 'SELLER #1',
          rightHeading: 'SELLER #2',
        }
      );
      renderOwnerPanels(
        { x: 66, yTop: 434, width: 470, height: 130 },
        {
          leftHeading: 'OWNER/GUARANTOR #1',
          rightHeading: 'OWNER/GUARANTOR #2',
        }
      );
      return;
    }

    if (basePage === 20) {
      clearRegionTop(page, pageHeight, { x: 46, yTop: 110, width: 534, height: 390 }, 3);
      renderOwnerPanels(
        { x: 78, yTop: 240, width: 452, height: 146 },
        {
          leftHeading: 'OWNER/GUARANTOR #1',
          rightHeading: 'OWNER/GUARANTOR #2',
        }
      );
      return;
    }

    if (basePage === 27) {
      clearRegionTop(page, pageHeight, { x: 46, yTop: 162, width: 534, height: 374 }, 3);
      renderSellerPanels(
        { x: 70, yTop: 194, width: 470, height: 126 },
        {
          leftHeading: 'SELLER #1',
          rightHeading: 'SELLER #2',
        }
      );
      renderOwnerPanels(
        { x: 70, yTop: 352, width: 470, height: 126 },
        {
          leftHeading: 'OWNER/GUARANTOR #1',
          rightHeading: 'OWNER/GUARANTOR #2',
        }
      );
      return;
    }

    if (basePage === 31) {
      let y = 44;
      drawCenteredTopText(page, pageHeight, 'Page 2 - APPENDIX A - CONTINUED', page.getSize().width / 2, y, 11.2, fonts.TimesBold);
      y += 38;
      drawTopText(page, pageHeight, 'LEGAL ADVICE', 52, y, 12, fonts.TimesBold);
      y += 18;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'The Seller affirms that it had ample opportunity to consult with legal counsel of its choosing regarding this Disclosure, and was advised by the Company to do so.',
        52,
        y,
        518,
        fonts.TimesRoman,
        10.3,
        12.2
      );
      y += 18;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'By signing below, Seller affirms understanding and acceptance of all fee terms disclosed above.',
        52,
        y,
        518,
        fonts.TimesRoman,
        10.3,
        12.2
      );
      renderSellerPanels(
        { x: 76, yTop: Math.max(y + 28, 196), width: 460, height: 150 },
        {
          leftHeading: 'SELLER #1',
          rightHeading: 'SELLER #2',
          companyText: sellerPartyText,
          companySize: 9.25,
          companyLeading: 10.5,
          companyFont: fonts.TimesRoman,
        }
      );
      drawInitialsFooter(page, pageHeight, fonts);
      return;
    }

    if (basePage === 32) {
      let y = 40;
      drawCenteredTopText(
        page,
        pageHeight,
        'AUTHORIZATION AGREEMENT FOR DIRECT DEPOSITS (ACH CREDITS) AND DIRECT PAYMENTS (ACH DEBITS)',
        page.getSize().width / 2,
        y,
        9.85,
        fonts.HelveticaBold
      );
      y += 24;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'This Authorization Agreement for Direct Deposits (ACH Credits) and Direct Payments ("Daily or Weekly ACH Authorization") is part of (and incorporated by reference into) the Merchant Agreement (the "Agreement").',
        50,
        y,
        522,
        fonts.HelveticaBold,
        8.95,
        10.45
      );
      y += 14;
      drawTopText(page, pageHeight, 'DEFINITIONS:', 50, y, 10.3, fonts.HelveticaBold);
      y += 22;
      y = drawInlineField(page, pageHeight, 'Company:', layout.companyName, 70, y, 500, fonts, {
        labelFont: fonts.HelveticaBold,
        valueFont: fonts.HelveticaBold,
        labelSize: 10.1,
        valueSize: 10.1,
      });
      y += 10;
      y = drawInlineField(page, pageHeight, 'Merchant:', sellerPartyText, 70, y, 500, fonts, {
        labelFont: fonts.HelveticaBold,
        valueFont: fonts.HelveticaBold,
        labelSize: 10.1,
        valueSize: 10.1,
        valueLeading: 11.15,
      });
      y += 4;
      drawTopText(page, pageHeight, "(Merchant's Legal Name)", 188, y, 9.9, fonts.HelveticaBold);
      y += 20;
      y = drawWrappedBlock(
        page,
        pageHeight,
        `Merchant Agreement: Merchant Agreement Between Company and Merchant Dated ${dateText}`,
        70,
        y,
        500,
        fonts.HelveticaBold,
        9.4,
        10.8
      );
      y += 14;
      drawTopText(page, pageHeight, 'DESIGNATED CHECKING ACCOUNT INFORMATION', 70, y, 10.2, fonts.HelveticaBold);
      y += 24;
      drawTopText(page, pageHeight, 'Account Number:', 70, y, 9.9, fonts.HelveticaBold);
      drawTopRule(page, pageHeight, 182, y + 10, 302, 0.8);
      drawTopText(page, pageHeight, String(formValues.account_number || '').trim(), 196, y, 9.9, fonts.Helvetica);
      y += 24;
      drawTopText(page, pageHeight, 'Routing Number:', 70, y, 9.9, fonts.HelveticaBold);
      drawTopRule(page, pageHeight, 182, y + 10, 302, 0.8);
      drawTopText(page, pageHeight, String(formValues.routing_number || '').trim(), 196, y, 9.9, fonts.Helvetica);
      y += 26;
      y = drawWrappedBlock(
        page,
        pageHeight,
        "Capitalized terms used in this Authorization Agreement without definition shall have the meanings set forth in the Merchant Agreement. Merchant should keep a copy of this important legal document for Merchant's records. By signing below Merchant attests that the Designated Checking Account was established for business purposes and not for personal, family or household purposes.",
        70,
        y,
        500,
        fonts.Helvetica,
        8.35,
        9.7
      );
      y += 12;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'DISBURSMENT OF PURCHASE PRICE. By signing below, Merchant authorizes Company to disburse the Purchase Price less any applicable fees set forth in the Agreement upon Advance approval by initiating an ACH credit to the bank account described below (or a substitute bank account Merchant later identifies and is acceptable to Company) (the "Account").',
        70,
        y,
        500,
        fonts.Helvetica,
        8.35,
        9.7
      );
      y += 10;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'COLLECTION OF FUNDS ARISING FROM FUTURE RECEIPTS. By signing below, Merchant authorizes Company to collect the funds that Company is entitled to receive under the Agreement by initiating ACH debits to the Account as follows:',
        70,
        y,
        500,
        fonts.Helvetica,
        8.35,
        9.7
      );
      y += 10;
      y = drawWrappedBlock(
        page,
        pageHeight,
        `For an amount up to ${String(formValues.daily_payment || '').trim()} ${String(formValues.payment_frequency || '').trim()} (or) Percentage of each banking deposit ${String(formValues.specified_pct || '').trim()} together with a nonrefundable monthly fee of $95 pursuant to section 1.22 of the terms and conditions of this PSFRA`,
        70,
        y,
        500,
        fonts.HelveticaBold,
        8.2,
        9.45
      );
      y += 10;
      y = drawWrappedBlock(
        page,
        pageHeight,
        "On the following days: Each business day. On the business day immediately following any business day(s) on which Merchant's bank was not open or was not able to process ACH transactions, the Company will debit the Designated Bank Account for an amount equal to the sum of (i) the Daily or Weekly Payment amount due on that business day plus ii) the Daily or Weekly Payment amounts due on the proceeding business day(s) when the Bank was not open or could not process ACH transactions.",
        70,
        y,
        500,
        fonts.Helvetica,
        8.2,
        9.45
      );
      y += 10;
      y = drawWrappedBlock(
        page,
        pageHeight,
        "MISCELLANEOUS. Merchant understands that Merchant is responsible for ensuring that funds arising from Future Receipts remain in the Account each day until Company debits the amount that the Agreement authorizes Company to debit from the Account for that day. Company is not responsible for any overdrafts or rejected transactions that may result from the Company debiting any of Merchant's accounts. The ACH authorizations provided for in this agreement will remain in effect until Company has received written notification from Merchant of its termination in such time and in such manner as to afford Company and Merchant's depository bank a reasonable opportunity to act on it. Company is not responsible for any fees charged by Merchant's bank as the result of credits or debits initiated under this Agreement. The origination of ACH transactions to Merchant's accounts, including, but not limited to, the Account, must comply with the provisions of U.S. law and NACHA Rules.",
        70,
        y,
        500,
        fonts.Helvetica,
        8.05,
        9.25
      );
      y += 12;
      drawTopText(page, pageHeight, 'MERCHANT SIGNATURE', 70, y, 9.9, fonts.HelveticaBold);
      y += 14;
      y = drawInlineField(page, pageHeight, "Merchant's Legal Name:", sellerPartyText, 70, y, 500, fonts, {
        labelFont: fonts.Helvetica,
        valueFont: fonts.Helvetica,
        labelSize: 8.9,
        valueSize: 8.9,
        valueLeading: 10.1,
      });
      renderSellerPanels(
        { x: 84, yTop: Math.max(y + 20, 574), width: 448, height: 142 },
        {
          leftHeading: 'SELLER #1',
          rightHeading: 'SELLER #2',
          companyText: sellerPartyText,
          companySize: hasSecondOwner ? 6.45 : 7.4,
          companyLeading: hasSecondOwner ? 7.2 : 8.45,
          companyFont: fonts.TimesRoman,
          headingSize: hasSecondOwner ? 12.2 : 12.6,
          headingGap: hasSecondOwner ? 16 : 18,
          bySize: 10.7,
          labelSize: hasSecondOwner ? 9.35 : 9.7,
          nameSize: hasSecondOwner ? 9.35 : 9.7,
          nameLeading: hasSecondOwner ? 10.45 : 11.0,
          companyLabelSize: hasSecondOwner ? 9.15 : 9.8,
          afterByGap: hasSecondOwner ? 16 : 20,
          signatureGap: hasSecondOwner ? 16 : 20,
          nameTopGap: hasSecondOwner ? 10 : 14,
          afterSsnGap: hasSecondOwner ? 10 : 18,
        }
      );
      drawInitialsFooter(page, pageHeight, fonts);
      return;
    }

    if ([34, 87, 141].includes(pageNum)) {
      clearRectTop(page, pageHeight, 0, 0, page.getSize().width, pageHeight, 0);

      const labelFont = fonts.HelveticaBold;
      const textFont = fonts.Helvetica;
      const serifFont = fonts.TimesRoman;
      const ink = PDFLib.rgb(0, 0, 0);
      const lightRule = PDFLib.rgb(0.72, 0.72, 0.72);
      const labelShade = PDFLib.rgb(0.93, 0.93, 0.93);
      const panelShade = PDFLib.rgb(0.985, 0.985, 0.975);
      const rule = (x1, y1, x2, y2, thickness = 0.45, color = ink) => {
        page.drawLine({
          start: { x: x1, y: pageHeight - y1 },
          end: { x: x2, y: pageHeight - y2 },
          thickness,
          color,
        });
      };
      const box = (x, yTop, width, height, fill = null, borderWidth = 0.45, borderColor = lightRule) => {
        const opts = {
          x,
          y: pageHeight - (yTop + height),
          width,
          height,
          borderColor,
          borderWidth,
        };
        if (fill) opts.color = fill;
        page.drawRectangle(opts);
      };
      const sectionTitle = (title, yTop, opts = {}) => {
        const x = opts.x || 48;
        const width = opts.width || 516;
        const size = opts.size || 9.2;
        drawTopText(page, pageHeight, title, x, yTop, size, labelFont);
        drawTopRule(page, pageHeight, x, yTop + 12, width, opts.thickness || 0.65);
      };
      const compactField = (label, value, x, yTop, width, opts = {}) => {
        const labelSize = opts.labelSize || 6.35;
        const valueSize = opts.valueSize || 6.75;
        const labelW = opts.labelW || 118;
        drawTopText(page, pageHeight, label, x, yTop, labelSize, labelFont);
        const valueX = x + labelW;
        const valueW = width - labelW;
        rule(valueX, yTop + 8, x + width, yTop + 8, 0.35, lightRule);
        if (value) {
          drawFittedWrappedBlock(page, pageHeight, value, valueX + 3, yTop - 1, valueW - 5, 12, textFont, {
            startSize: valueSize,
            minSize: 5.2,
            leadingFactor: 1.04,
            maxLines: 2,
          });
        }
      };

      let y = 34;
      drawCenteredTopText(page, pageHeight, 'PRE-FUNDING QUESTIONNAIRE', page.getSize().width / 2, y, 14.4, fonts.TimesBold);
      drawTopText(page, pageHeight, 'Initials:', 486, y, 9.3, labelFont);
      drawTopRule(page, pageHeight, 529, y + 10, 34, 0.65);

      y += 28;
      box(46, y, 520, 168, panelShade, 0.55, lightRule);
      box(46, y, 520, 18, labelShade, 0.55, lightRule);
      drawTopText(page, pageHeight, 'BUSINESS INFORMATION & FACTORING TERMS', 54, y + 5, 8.7, labelFont);
      y += 27;
      const leftX = 58;
      const rightX = 324;
      const colW = 224;
      compactField('Business Name:', businessName, leftX, y, 490, { labelW: 100, valueSize: 6.8 });
      y += 13;
      compactField('Best Email Address:', String(formValues.email || '').trim(), leftX, y, colW, { labelW: 94, valueSize: 6.35 });
      compactField('Best Contact Number:', '', rightX, y, colW, { labelW: 98 });
      y += 13;
      compactField('What is the Nature of your business?', '', leftX, y, colW, { labelW: 132 });
      compactField('Total Current MCA Balances:', '', rightX, y, colW, { labelW: 118 });
      y += 13;
      compactField('Current Bank Account Balance:', '', leftX, y, colW, { labelW: 126 });
      compactField('How long have you been in business?', '', rightX, y, colW, { labelW: 138 });
      y += 13;
      compactField('Were you always the owner of the business?', '', leftX, y, 490, { labelW: 170 });
      y += 13;
      compactField('Expected gross revenue for next 3 months:  Month 1 / Month 2 / Month 3', '', leftX, y, 490, { labelW: 274 });
      y += 13;
      compactField('What are you using the money for?', '', leftX, y, 490, { labelW: 142 });
      y += 15;
      compactField('Estimated Remittance Amount:', String(formValues.daily_payment || '').trim(), leftX, y, colW, { labelW: 124 });
      compactField('Net Funding Deposit After Fees:', String(formValues.net_funded || '').trim(), rightX, y, colW, { labelW: 130 });
      y += 13;
      compactField('Receivables Purchased Amount:', String(formValues.payback_amount || '').trim(), leftX, y, colW, { labelW: 130 });
      compactField('Purchase Price:', String(formValues.purchase_price || '').trim(), rightX, y, colW, { labelW: 86 });
      y += 13;
      compactField('Do you FULLY understand the terms of this agreement?', '', leftX, y, 306, { labelW: 220 });
      compactField('Frequency:', String(formValues.payment_frequency || '').trim(), 396, y, 152, { labelW: 58 });

      y = 241;
      sectionTitle('QUESTIONS & DISCLOSURES', y, { x: 46, width: 520, size: 11.3, thickness: 0.9 });
      drawTopText(page, pageHeight, 'Answer', 526, y + 1, 9.3, labelFont);
      y += 22;
      const questionX = 69;
      const questionW = 438;
      const answerX = 524;
      const questions = [
        'Do you acknowledge and understand that this contract/agreement/transaction is not, in any way, a loan but rather a Factoring Agreement for the Factoring of your Receivables?',
        'We do not make any promises regarding future funding. Has anyone made you any promises of a loan or further funding based on your performance with this advance?',
        'Do you acknowledge and understand that during the underwriting process, we collect client/vendor/receivable/Account Debtors information by accessing your bank, credit card processing, or bookkeeping account login? This information will be used in the event of a default or breach of contract to enforce our Security Interest in your payments.',
        'Do you acknowledge and understand that the client information we collect includes contact details, which may be used to send UCC Liens to your clients in the event of a default or breach?',
        'Do you acknowledge and understand that a blanket UCC-1 security interest will be filed on all accounts receivable, receipts, instruments, contract rights, and other rights to receive payment of money, patents, chattel paper, licenses, leases, and general intangibles, whether currently owned or acquired in the future, as well as all books and records relating to any of the mentioned items? Additionally, do you understand that UCC lien notices may be served to known or suspected custodians or managers of the aforementioned in the event of a default or breach of contract?',
        'As of the date of this Agreement, Seller represents that it is not insolvent, has not filed for bankruptcy protection, and there are no pending involuntary petitions against Seller. Seller further confirms that it has not consulted with a bankruptcy attorney within the past 6 months and has no intention of permanently or temporarily closing or ceasing operations for the 6-month period after this Agreement. Seller warrants that it does not anticipate filing a bankruptcy petition or facing an involuntary petition. Any misrepresentation of these statements will constitute a breach of contract.'
      ];
      questions.forEach((question, idx) => {
        const questionSize = 8.55;
        const questionLeading = 9.85;
        const lines = wrapToWidth(question, serifFont, questionSize, questionW);
        const rowH = Math.max(33, (lines.length * questionLeading) + 11);
        rule(46, y - 5, 566, y - 5, 0.35, lightRule);
        drawTopText(page, pageHeight, `${idx + 1}.`, 52, y, 8.35, labelFont);
        let rowTextY = y;
        lines.forEach(line => {
          drawTopText(page, pageHeight, line, questionX, rowTextY, questionSize, serifFont);
          rowTextY += questionLeading;
        });
        drawTopRule(page, pageHeight, answerX, y + 9, 38, 0.55);
        y += rowH;
      });

      y += 6;
      drawWrappedBlock(
        page,
        pageHeight,
        'I Declare under Penalty of Perjury (Under the Laws of the United States of America) that the foregoing is true and correct:',
        46,
        y,
        520,
        fonts.TimesBold,
        10.0,
        11.6
      );
      y += 28;
      drawTopText(page, pageHeight, 'X', 86, y, 11.2, labelFont);
      drawTopRule(page, pageHeight, 101, y + 10, 186, 0.8);
      drawTopText(page, pageHeight, 'Date:', 354, y, 9.5, labelFont);
      drawTopRule(page, pageHeight, 386, y + 10, 126, 0.8);
      drawInitialsFooter(page, pageHeight, fonts);
      return;
    }

    if (basePage === 35) {
      let y = 40;
      drawCenteredTopText(page, pageHeight, 'DECLARATION OF ORDINARY COURSE OF BUSINESS AND INFORMED PARTICIPATION', page.getSize().width / 2, y, 10.8, fonts.TimesBold);
      y += 38;
      y = drawWrappedBlock(
        page,
        pageHeight,
        `This Declaration is made and affirmed by the undersigned on behalf of themselves and ${sellerPartyText} (collectively, the "Merchant"), in connection with a funding transaction with ${layout.companyName} (the "Company").`,
        52,
        y,
        518,
        fonts.Helvetica,
        8.95,
        10.45
      );
      y += 10;
      drawTopText(page, pageHeight, '1. Voluntary Execution & Business Purpose', 52, y, 10, fonts.HelveticaBold);
      y += 16;
      y = drawWrappedBlock(
        page,
        pageHeight,
        "The undersigned declares under penalty of perjury that this transaction was entered into in the ordinary course of Merchant's business for lawful commercial purposes, including but not limited to: working capital, payroll, vendor payments, or business continuity. The undersigned:",
        70,
        y,
        500,
        fonts.Helvetica,
        8.55,
        9.8
      );
      y += 4;
      y = drawBulletList(page, pageHeight, [
        'Had adequate time to review the Agreement;',
        'Was not coerced or rushed;',
        'Had the opportunity to consult legal counsel;',
        'Did not rely on any oral promises or side deals;',
        'Executed the Agreement knowingly, voluntarily, and with full understanding.'
      ], 86, y, 472, fonts.Helvetica, 8.4, { leading: 9.5, paraGap: 1.8 });
      y += 6;
      drawTopText(page, pageHeight, '2. Independent Business Judgment', 52, y, 10, fonts.HelveticaBold);
      y += 16;
      y = drawWrappedBlock(page, pageHeight, 'The Merchant affirms that:', 70, y, 500, fonts.Helvetica, 8.55, 9.8);
      y += 4;
      y = drawBulletList(page, pageHeight, [
        'No fraud, deception, or economic duress was involved;',
        'There was no abuse of bargaining power or manipulation;',
        'All terms were disclosed in writing and the Merchant had the ability to decline or negotiate;',
        'The Merchant is not relying on future performance guarantees or unwritten promises.'
      ], 86, y, 472, fonts.Helvetica, 8.4, { leading: 9.5, paraGap: 1.8 });
      y += 6;
      drawTopText(page, pageHeight, '3. Waiver of Defenses', 52, y, 10, fonts.HelveticaBold);
      y += 16;
      y = drawWrappedBlock(page, pageHeight, 'The Merchant irrevocably waives the right to assert now or later that:', 70, y, 500, fonts.Helvetica, 8.55, 9.8);
      y += 4;
      y = drawBulletList(page, pageHeight, [
        'It acted under economic duress or coercion;',
        'The Agreement was outside the ordinary course of business;',
        'It lacked capacity or legal understanding;',
        'It was misled or pressured;',
        'The Company engaged in unfair or deceptive practices.'
      ], 86, y, 472, fonts.Helvetica, 8.4, { leading: 9.5, paraGap: 1.8 });
      y += 6;
      drawTopText(page, pageHeight, '4. Governing Law & Enforcement', 52, y, 10, fonts.HelveticaBold);
      y += 16;
      y = drawWrappedBlock(
        page,
        pageHeight,
        "This Declaration is governed by the laws of the State of New York and may be used as evidence of the Merchant's knowing and voluntary consent to the Agreement.",
        70,
        y,
        500,
        fonts.Helvetica,
        8.55,
        9.8
      );
      y += 10;
      drawTopText(page, pageHeight, '5. Penalty of Perjury', 52, y, 10, fonts.HelveticaBold);
      y += 16;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'The undersigned declares under penalty of perjury under the laws of the United States of America and the State of New York that the foregoing is true and correct.',
        70,
        y,
        500,
        fonts.Helvetica,
        8.55,
        9.8
      );
      y += 22;
      drawTopText(page, pageHeight, `Executed on ${dateText}`, 84, y, 10.4, fonts.Helvetica);
      drawTopText(page, pageHeight, '(Date)', 212, y + 20, 9.25, fonts.Helvetica);
      renderDeclarationExecutionPanels(
        { x: 76, yTop: Math.max(y + 56, 584), width: 460, height: 132 },
        {
          leftHeading: 'FOR THE OWNER/SELLER (#1)',
          rightHeading: 'FOR THE OWNER/SELLER (#2)',
        }
      );
      drawInitialsFooter(page, pageHeight, fonts);
      return;
    }

    if (basePage === 37) {
      const derived = buildDerivedValues(formValues);
      const tableX = 50;
      const tableY = 42;
      const tableW = 512;
      const leftW = 286;
      const rightW = tableW - leftW;
      const rowFill = PDFLib.rgb(0.94, 0.94, 0.94);
      const white = PDFLib.rgb(1, 1, 1);
      const black = PDFLib.rgb(0, 0, 0);
      const borderColor = PDFLib.rgb(0.64, 0.64, 0.64);
      let y = tableY;

      function cell(x, yTop, width, height, fill = white, borderWidth = 0.45) {
        page.drawRectangle({
          x,
          y: pageHeight - (yTop + height),
          width,
          height,
          color: fill,
          borderColor,
          borderWidth,
        });
      }

      function drawCellText(text, x, yTop, width, height, font, opts = {}) {
        const startSize = opts.startSize ?? 10.6;
        const minSize = opts.minSize ?? 7.2;
        const leadingFactor = opts.leadingFactor ?? 1.12;
        const maxLines = opts.maxLines ?? null;
        return drawFittedWrappedBlock(
          page,
          pageHeight,
          String(text || ''),
          x,
          yTop,
          width,
          height,
          font,
          { startSize, minSize, leadingFactor, maxLines }
        );
      }

      function row(label, value, height, opts = {}) {
        const leftX = tableX;
        const rightX = tableX + leftW;
        cell(leftX, y, leftW, height, opts.leftFill === false ? white : rowFill);
        cell(rightX, y, rightW, height, white);
        if (opts.header) {
          drawCellText(label, leftX + 5, y + 6, leftW - 10, height - 10, fonts.TimesBold, {
            startSize: 10.9,
            minSize: 9,
            leadingFactor: 1.05,
            maxLines: 1,
          });
        } else if (opts.kind === 'disbursement') {
          drawCellText('Disbursement Amount', leftX + 5, y + 6, leftW - 10, 15, fonts.TimesBold, {
            startSize: 11.3,
            minSize: 9,
            maxLines: 1,
          });
          drawCellText('[Total Amount of the Sales-Based Financing minus (-) Fees Deducted or Withheld at Disbursement]', leftX + 146, y + 7, leftW - 151, 18, fonts.TimesRoman, {
            startSize: 7.6,
            minSize: 6.3,
            leadingFactor: 1.05,
            maxLines: 2,
          });
          drawCellText('Please note: In the case of a renewal, the "Disbursement Amount" mentioned above may also include the payoff of your current outstanding balance.', leftX + 5, y + 27, leftW - 10, height - 31, fonts.TimesBold, {
            startSize: 8.75,
            minSize: 7.1,
            leadingFactor: 1.08,
            maxLines: 3,
          });
        } else if (opts.kind === 'repayment') {
          drawCellText('Total Repayment Amount', leftX + 5, y + 6, leftW - 10, 14, fonts.TimesBold, {
            startSize: 11.1,
            minSize: 8.6,
            maxLines: 1,
          });
          drawCellText('[Disbursement Amount plus (+) Finance Charge]', leftX + 5, y + 21, leftW - 10, height - 25, fonts.TimesRoman, {
            startSize: 9.1,
            minSize: 7.2,
            maxLines: 2,
          });
        } else if (opts.kind === 'totalCost') {
          drawCellText('Total Cost', leftX + 5, y + 6, leftW - 10, 15, fonts.TimesBold, {
            startSize: 11.1,
            minSize: 8.6,
            maxLines: 1,
          });
          drawCellText('[Repayment amount (-) Disbursement Amount] this figure does not include all other potential fees that can be incurred throughout the life of this contract.', leftX + 5, y + 21, leftW - 10, height - 25, fonts.TimesRoman, {
            startSize: 9.2,
            minSize: 7.1,
            leadingFactor: 1.08,
          });
        } else if (opts.kind === 'estimated') {
          drawCellText('Estimated Number of Payments', leftX + 5, y + 6, leftW - 10, 15, fonts.TimesBold, {
            startSize: 11.0,
            minSize: 8.6,
            maxLines: 1,
          });
          drawCellText('[Number of payments expected, based on the projected sales volume, to equal the Total Repayment Amount]', leftX + 5, y + 22, leftW - 10, 34, fonts.TimesRoman, {
            startSize: 9.2,
            minSize: 7.2,
            leadingFactor: 1.08,
          });
          drawCellText('A reasonable range may be provided ONLY for transactions with a variable payment schedule.', leftX + 5, y + 76, leftW - 10, height - 82, fonts.TimesRoman, {
            startSize: 9.2,
            minSize: 7.2,
            leadingFactor: 1.1,
          });
        } else {
          drawCellText(label, leftX + 5, y + 6, leftW - 10, height - 10, fonts.TimesBold, {
            startSize: opts.labelSize ?? 10.9,
            minSize: opts.labelMin ?? 7.5,
            leadingFactor: 1.08,
            maxLines: opts.labelMaxLines ?? null,
          });
        }
        if (value) {
          drawCellText(value, rightX + 7, y + 6, rightW - 14, height - 10, opts.valueFont || fonts.TimesRoman, {
            startSize: opts.valueSize ?? 11.2,
            minSize: opts.valueMin ?? 7.2,
            leadingFactor: opts.valueLeadingFactor ?? 1.1,
            maxLines: opts.valueMaxLines ?? null,
          });
        }
        y += height;
      }

      row('SALES-BASED FINANCING DISCLOSURE FORM', '', 22, { header: true, leftFill: false });
      row('Disclosure Date:', formatDate(formValues.date || ''), 22, { valueSize: 11.5, valueMaxLines: 1 });
      row('Recipient’s Name', sellerPartyText, 52, { valueSize: 9.7, valueMin: 7.2, valueMaxLines: 4 });
      row('Recipient’s Address', addressText, 42, { valueSize: 11.1, valueMin: 8.0, valueMaxLines: 3 });
      row('Provider’s Address', `${layout.companyName}\n${layout.principalOffice}`, 42, { valueSize: 10.4, valueMin: 7.8, valueMaxLines: 3 });
      row('Providers Phone Number:', layout.phoneNumber, 24, { valueSize: 10.8, valueMaxLines: 1 });
      row('Provider’s E-Mail Address:', layout.submissionsEmail, 24, { valueSize: 10.4, valueMin: 7.2, valueMaxLines: 1 });
      row('Total Amount of the Sales-Based Financing', String(formValues.purchase_price || '').trim(), 24, { valueSize: 10.9, valueMaxLines: 1 });
      row('Fees Deducted or Withheld at Disbursement', psfText, 24, { valueSize: 10.9, valueMaxLines: 1 });
      row('', String(formValues.net_funded || '').trim(), 62, { kind: 'disbursement', valueSize: 11.2, valueMaxLines: 1 });
      row('Finance Charge', psfText, 24, { valueSize: 10.9, valueMaxLines: 1 });
      row('', String(formValues.payback_amount || '').trim(), 34, { kind: 'repayment', valueSize: 10.9, valueMaxLines: 1 });
      row('', derived.disclosure_total_cost, 62, { kind: 'totalCost', valueSize: 10.9, valueMaxLines: 1 });
      row('', derived.disclosure_estimated_payments, 126, { kind: 'estimated', valueSize: 10.9, valueMaxLines: 1 });
      row('Payment Schedule', '', 24, { labelSize: 10.9, labelMaxLines: 1 });
      row('Amount of each payment:', String(formValues.daily_payment || '').trim(), 24, { valueSize: 10.9, valueMaxLines: 1 });
      row('Frequency of payments:', String(formValues.payment_frequency || '').trim(), 24, { valueSize: 10.9, valueMaxLines: 1 });
      row('Method of Payment:', 'ACH Debit', 24, { valueSize: 10.9, valueMaxLines: 1 });
      page.drawLine({
        start: { x: tableX, y: pageHeight - tableY },
        end: { x: tableX + tableW, y: pageHeight - tableY },
        thickness: 0.8,
        color: black,
      });
      drawInitialsFooter(page, pageHeight, fonts);
      return;
    }

    if (basePage === 38) {
      clearRegionTop(page, pageHeight, { x: 52, yTop: 604, width: 508, height: 130 }, 2.5);
      renderSellerPanels(
        { x: 76, yTop: 628, width: 460, height: 104 },
        {
          leftHeading: 'Seller: #1',
          rightHeading: 'Seller: #2',
        }
      );
      return;
    }

    if (basePage === 39) {
      clearRegionTop(page, pageHeight, { x: 44, yTop: 34, width: 540, height: 700 }, 3);
      let y = 44;
      drawTopText(page, pageHeight, `AUTHORIZATION TO ${layout.shortName}`, 52, y, 12.8, fonts.TimesBold);
      y += 26;
      drawWrappedBlock(
        page,
        pageHeight,
        `Seller hereby irrevocably authorizes ${layout.companyName} (“${layout.shortName}”), and any designee of ${layout.shortName}, at Seller's sole expense, to exercise, at any time and at the discretion of ${layout.shortName} or its designee, any or all of the following powers until all obligations have been paid in full and ${layout.shortName} has filed or authorized the filing of a UCC Financing Statement terminating its Security Interest:`,
        52,
        y,
        516,
        fonts.TimesRoman,
        9.0,
        10.25
      );
      y += 45;
      y = drawBulletList(page, pageHeight, [
        `(a) Receive, endorse, assign, deliver, accept, and deposit, in the name of ${layout.shortName} or Seller, any and all cash, checks, commercial paper, drafts, remittances, and other instruments and documents related to the Purchased Accounts, Collateral, and Proceeds thereof.`,
        `(b) Take or initiate, in the name of ${layout.shortName} or Seller, any necessary or desirable steps, actions, suits, or proceedings to effect collection of or realization upon the purchased accounts and collateral.`,
        `(c) Execute Financing Statements or amendments in the name of Seller and file them against Seller in favor of ${layout.shortName} with respect to the collateral.`,
        `(d) Pay any sums necessary to discharge any lien or encumbrance that is or may become senior to ${layout.shortName}'s Security Interest in the Collateral, or that may, in ${layout.shortName}'s judgment, interfere inappropriately with ${layout.shortName}'s rights. Such sums shall be included as Obligations hereunder, and late/default charges shall accrue and be due and payable in connection with said sums.`,
        `(e) File mechanics lien or related notices or claims under any payment bond, in connection with goods or services sold by Seller for the improvement of realty, in the name of Seller or ${layout.shortName} or both.`,
        `(f) Notify, at any time and without notice to or the assent of Seller, any Account Debtor obligated or suspected to be obligated (at ${layout.shortName}'s sole discretion) regarding any account that the account has been assigned to ${layout.shortName} by Seller and that payment thereof is to be made solely to ${layout.shortName}.`,
        `(g) Communicate directly with Seller's Account Debtors, or suspected account debtors, to verify the amount and validity of any account created by Seller.`,
        `(h) ${layout.shortName} may, but has no duty to, and Merchant/Seller hereby authorizes ${layout.shortName} to, execute and file, on behalf of Merchant/Seller or in ${layout.shortName}'s name, mechanic’s liens and all other notices and documents to create, perfect, foreclose and/or release any lien for work performed or materials provided to improve real property. Except as otherwise instructed by ${layout.shortName}, Merchant/Seller is authorized to file any such mechanics liens and other notices and documents at Merchant/Seller’s discretion. Merchant/Seller hereby agrees that any release or mechanic’s lien waiver signed by ${layout.shortName} on behalf of Merchant/Seller shall be sufficient release for any Account Debtor (as Defined by the UCC) to release any payment on Accounts and to effect the deposit and collection thereof.`
      ], 52, y, 516, fonts.TimesRoman, 8.2, { indent: 14, leading: 8.9, paraGap: 1.5 });
      y += 8;
      y = drawWrappedBlock(
        page,
        pageHeight,
        `Furthermore, Seller authorizes ${layout.shortName}, at its sole discretion, to reveal and release Personal Identification Information (such as date of birth, social security number, home address, EIN, etc.) in an effort to locate potential balances and accounts. Seller hereby releases, exculpates, and holds ${layout.shortName}, its officers, employees, and designees harmless from any liability arising from acts under this Agreement, whether of omission or commission, except in cases of willful misconduct. Seller also releases any claims arising from ${layout.shortName}'s endorsement and deposit of checks issued by Seller's customers stating that they were in full payment of an account, but were issued for less than the full amount owed on the account. ${layout.shortName} shall not be liable to Seller for lost profits or other special or consequential damages. Additionally, ${layout.shortName} shall not be liable for any damages, special or consequential, arising from the disclosure of Personal Identification Information or any other information, or any interference by ${layout.shortName} in its communication with suspected account debtors.`,
        52,
        y,
        516,
        fonts.TimesRoman,
        8.2,
        9.0
      );
      y += 10;
      drawWrappedBlock(
        page,
        pageHeight,
        'I, the undersigned acknowledge that I have read, comprehended, and accepted all the provisions stated above.',
        52,
        y,
        516,
        fonts.TimesBold,
        8.8,
        9.8
      );
      renderSellerPanels(
        { x: 76, yTop: Math.max(y + 30, 506), width: 460, height: 128 },
        {
          companyText: sellerPartyText,
          companySize: 7.4,
          companyLeading: 8.35,
          companyFont: fonts.TimesRoman,
          headingSize: 12.2,
          headingGap: 18,
          bySize: 10.7,
          labelSize: 9.7,
          nameSize: 9.7,
          nameLeading: 11,
          companyLabelSize: 9.8,
          afterSsnGap: 18,
        }
      );
      drawInitialsFooter(page, pageHeight, fonts);
      return;
    }

    if (basePage === 41) {
      clearRegionTop(page, pageHeight, { x: 44, yTop: 34, width: 540, height: 700 }, 3);
      let y = 62;
      drawCenteredTopText(page, pageHeight, 'Continued - CONSENT AND ACKNOWLEDGEMENT OF LIQUIDATED DAMAGES AND FEES', page.getSize().width / 2, y, 10.8, fonts.TimesBold);
      y += 16;
      drawCenteredTopText(page, pageHeight, '(Page 2)', page.getSize().width / 2, y, 10.2, fonts.TimesBold);
      y += 42;
      drawTopText(page, pageHeight, '5. No Coercion; Opportunity for Counsel', 52, y, 12, fonts.TimesBold);
      y += 22;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'Seller affirms that this Consent was entered into voluntarily, without coercion or misrepresentation, with full knowledge of the consequences and the opportunity to seek legal advice.',
        52,
        y,
        516,
        fonts.TimesRoman,
        11.0,
        13.2
      );
      y += 24;
      drawTopText(page, pageHeight, '6. Governing Law and Severability', 52, y, 12, fonts.TimesBold);
      y += 22;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'This Consent shall be governed by the laws of the State of New York. If any provision is deemed invalid or unenforceable, the remainder shall continue in full force and effect.',
        52,
        y,
        516,
        fonts.TimesRoman,
        11.0,
        13.2
      );
      renderOwnerPanels(
        { x: 82, yTop: Math.max(y + 56, 326), width: 450, height: 154 },
        {
          leftHeading: 'OWNER/GUARANTOR #1',
          rightHeading: 'OWNER/GUARANTOR #2',
        }
      );
      return;
    }

    if (basePage === 42) {
      clearRegionTop(page, pageHeight, { x: 44, yTop: 34, width: 540, height: 700 }, 3);
      let y = 40;
      drawTopText(page, pageHeight, 'CONSENT AND ACKNOWLEDGEMENT OF GOVERNING LAW, VENUE, JURISDICTION, AND ARBITRATION', 52, y, 9.9, fonts.HelveticaBold);
      y += 28;
      y = drawWrappedBlock(
        page,
        pageHeight,
        `This Consent and Acknowledgement ("Consent") is made by and between ${sellerPartyText} ("Seller") and ${layout.companyName} ("Company").`,
        76,
        y,
        492,
        fonts.Helvetica,
        9.4,
        10.9
      );
      y += 12;
      drawTopText(page, pageHeight, '1. Acknowledgment of Governing Law, Venue, Jurisdiction, and Arbitration', 52, y, 9.5, fonts.HelveticaBold);
      y += 18;
      drawTopText(page, pageHeight, '1.1 Informed Consent to Governing Law and Venue', 52, y, 9.35, fonts.HelveticaBold);
      y += 16;
      y = drawWrappedBlock(page, pageHeight, 'The Seller irrevocably acknowledges and agrees that:', 52, y, 516, fonts.Helvetica, 9.15, 10.55);
      y += 4;
      y = drawBulletList(page, pageHeight, [
        'This Agreement shall be governed by and construed in accordance with the laws of the State of New York, without regard to its conflict of laws principles.',
        'Any and all legal proceedings or arbitration proceedings arising from or relating to the Agreement shall be brought exclusively in either (a) the courts of the State of New York, County of New York (Manhattan), or (b) binding arbitration administered in accordance with New York law.'
      ], 68, y, 500, fonts.Helvetica, 8.9, { leading: 10.2, paraGap: 2.5 });
      y += 6;
      drawTopText(page, pageHeight, '1.2 Express Agreement to Jurisdiction and Waiver of Objections', 52, y, 9.35, fonts.HelveticaBold);
      y += 16;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'The Seller knowingly, voluntarily, and irrevocably consents to the exclusive jurisdiction of the State and Federal courts located in Nassau County, New York. The Seller:',
        52,
        y,
        516,
        fonts.Helvetica,
        9.05,
        10.45
      );
      y += 4;
      y = drawBulletList(page, pageHeight, [
        'Waives any and all objections to jurisdiction or venue on the grounds of forum non conveniens, inconvenience, or otherwise.',
        'Agrees that any challenge to jurisdiction, venue, arbitration, or enforcement of any judgment shall constitute a material breach of the Agreement.'
      ], 68, y, 500, fonts.Helvetica, 8.85, { leading: 10.1, paraGap: 2.5 });
      y += 6;
      drawTopText(page, pageHeight, '1.3 Legal Consultation and Acknowledged Understanding', 52, y, 9.35, fonts.HelveticaBold);
      y += 16;
      y = drawWrappedBlock(page, pageHeight, 'The Seller affirms that:', 52, y, 516, fonts.Helvetica, 9.05, 10.45);
      y += 4;
      y = drawBulletList(page, pageHeight, [
        'They had a full and fair opportunity to consult with independent legal counsel before signing.',
        'They are not relying on any oral representation or side agreement regarding the venue, law, or arbitration terms.',
        'They understand the legal consequences of consenting to New York law and jurisdiction and waive any requirement of further legal consultation.'
      ], 68, y, 500, fonts.Helvetica, 8.85, { leading: 10.05, paraGap: 2.4 });
      y += 6;
      drawTopText(page, pageHeight, '1.4 Enforceability and Waiver of Defenses', 52, y, 9.35, fonts.HelveticaBold);
      y += 16;
      y = drawWrappedBlock(page, pageHeight, 'The Seller expressly waives any defense to enforcement of the foregoing provisions, including without limitation:', 52, y, 516, fonts.Helvetica, 9.05, 10.45);
      y += 4;
      y = drawBulletList(page, pageHeight, [
        'Claims of lack of sophistication,',
        'Procedural or substantive unconscionability,',
        'Economic duress,',
        'Inequality of bargaining power,',
        'Or alleged lack of opportunity to negotiate or consult counsel.'
      ], 68, y, 500, fonts.Helvetica, 8.85, { leading: 10, paraGap: 2.1 });
      y += 4;
      y = drawWrappedBlock(page, pageHeight, 'The Seller acknowledges that this Consent was executed at arm’s length, in good faith, and with full awareness of the legal implications.', 52, y, 516, fonts.HelveticaBold, 8.95, 10.3);
      y += 10;
      drawTopText(page, pageHeight, '2. Binding Effect', 52, y, 9.3, fonts.HelveticaBold);
      y += 14;
      y = drawWrappedBlock(page, pageHeight, 'This Consent shall be binding upon the Seller, their agents, representatives, heirs, successors, and assigns, and shall be enforceable in any court of competent jurisdiction, including but not limited to courts in the State of New York.', 52, y, 516, fonts.Helvetica, 8.9, 10.2);
      y += 8;
      drawTopText(page, pageHeight, '3. Severability', 52, y, 9.3, fonts.HelveticaBold);
      y += 14;
      y = drawWrappedBlock(page, pageHeight, 'If any provision of this Consent is found to be invalid, illegal, or unenforceable in whole or in part, the remaining provisions shall remain in full force and effect.', 52, y, 516, fonts.Helvetica, 8.9, 10.2);
      y += 8;
      drawTopText(page, pageHeight, '4. Governing Law', 52, y, 9.3, fonts.HelveticaBold);
      y += 14;
      y = drawWrappedBlock(page, pageHeight, 'This Consent shall be governed by and construed in accordance with the laws of the State of New York, and the parties expressly waive the application of any conflicting laws of any other state or jurisdiction.', 52, y, 516, fonts.Helvetica, 8.9, 10.2);
      y += 14;
      drawTopText(page, pageHeight, 'IN WITNESS WHEREOF, the undersigned have executed this Consent as of', 52, y, 9.15, fonts.Helvetica);
      renderOwnerPanels(
        { x: 82, yTop: Math.max(y + 24, 520), width: 450, height: 154 },
        {
          leftHeading: 'OWNER/GUARANTOR #1',
          rightHeading: 'OWNER/GUARANTOR #2',
          headingSize: hasSecondOwner ? 11.6 : 12.5,
          headingGap: hasSecondOwner ? 16 : 18,
          bySize: 10.8,
          labelSize: hasSecondOwner ? 9.35 : 9.9,
          nameSize: hasSecondOwner ? 9.35 : 9.9,
          nameLeading: hasSecondOwner ? 10.45 : 11.25,
          afterByGap: hasSecondOwner ? 16 : 20,
          signatureGap: hasSecondOwner ? 16 : 20,
          nameTopGap: hasSecondOwner ? 10 : 14,
          afterSsnGap: hasSecondOwner ? 10 : 24,
        }
      );
      drawInitialsFooter(page, pageHeight, fonts, hasSecondOwner ? { yTop: 770 } : {});
      return;
    }

    if (basePage === 53) {
      clearRegionTop(page, pageHeight, { x: 44, yTop: 34, width: 540, height: 700 }, 3);
      let y = 46;
      drawTopText(page, pageHeight, 'REQUIRED ACKNOWLEDGMENT BY INITIALS', 52, y, 19, fonts.TimesBold);
      y += 34;
      drawTopText(page, pageHeight, '(Seller and each Owner/Guarantor must initial each line)', 52, y, 10, fonts.TimesRoman);
      y += 24;
      const initialLines = [
        'Broker is not Company’s agent and cannot bind Company.',
        'I selected the Broker; Company did not choose or require one.',
        'Broker compliance is my responsibility, not Company’s.',
        'Broker issues are not a defense to my obligations.',
        'Broker fees are my cost; Company remits as a conduit only.',
        'I waive broker-related claims and agree to indemnify Company.'
      ];
      initialLines.forEach(line => {
        page.drawRectangle({
          x: 52,
          y: pageHeight - (y + 15),
          width: 40,
          height: 18,
          color: PDFLib.rgb(1, 0.93, 0.4),
          borderWidth: 0,
        });
        drawTopText(page, pageHeight, '[ ] ____', 56, y, 10.4, fonts.TimesRoman);
        drawTopText(page, pageHeight, line, 94, y, 10.2, fonts.TimesRoman);
        y += 20;
      });
      y += 10;
      drawTopText(page, pageHeight, 'VOLUNTARY EXECUTION & OPPORTUNITY FOR COUNSEL', 52, y, 10.9, fonts.TimesBold);
      y += 18;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'The undersigned Seller and Guarantors affirm that they have read this Addendum separately from the Agreement, had the opportunity to consult independent legal counsel, and are signing knowingly, voluntarily, and without coercion or duress.',
        52,
        y,
        516,
        fonts.TimesRoman,
        9.6,
        11.1
      );
      renderSellerPanels(
        { x: 84, yTop: Math.max(y + 42, 340), width: 448, height: 154 },
        {
          leftHeading: 'Seller: #1',
          rightHeading: 'Seller: #2',
        }
      );
      drawInitialsFooter(page, pageHeight, fonts);
      return;
    }

    if (pageIsInGroup(pageNum, 'ackOpening')) {
      const region = { x: 44, yTop: 54, width: 536, height: 678 };
      clearRegionTop(page, pageHeight, region, 3);
      let y = 70;
      const intro = `I, ${owner1Text}, on behalf of Seller, hereby acknowledge, fully agree with and understand:`;
      y = drawWrappedBlock(page, pageHeight, intro, 52, y, 520, fonts.TimesBold, 11.5, 14);
      y += 10;
      y = drawBulletList(page, pageHeight, [
        'I am aware of my rights and responsibilities under the reconciliation clause of this contract.',
        `I understand and acknowledge that there have been no promises of additional capital from ${layout.companyName} (“${layout.shortName}”) or any ISO (broker) beyond what is explicitly mentioned in this contract.`,
        `I am informed that according to the current policy, I can seek additional capital from ${layout.shortName} once they have paid 70% of the receipts purchased amount.`,
        `I acknowledge that ${layout.shortName} does not permit outside fees, and no discussions have taken place regarding additional fees. The fee amount for this agreement is ${psfText}, which will be deducted from the funding amount.`,
        `I confirm that there have been no contacts or communications from Third Party Debt Companies regarding this agreement dated ${dateText}.`,
        `I have personally chosen the ISO (Broker) who introduced me to ${layout.shortName}, and I understand that the ISO acts as an independent third party. Furthermore, I am aware that ${layout.shortName} has not conducted any investigation into the ISO's marketing, background, or business practices. Therefore, I agree to hold ${layout.shortName} and its agents, affiliates, or associates harmless and indemnify them against any issues, claims, damages, liabilities, losses, suits, costs, and expenses arising from interactions with the ISO.`,
        'Additionally, upon my execution of this contract, I hereby consent to provide a copy of this signed contract to the ISO or Broker.',
        'Appendix A: The Fee Structure comprehensively outlines all fees, including but not limited to bounced/returned/NSF payment and default fees, and explains how these fees are assessed, charged, and applied. I have thoroughly read, understood, and agreed to Appendix A: The Fee Structure. I am fully aware of the fees, how to avoid them, and the automatic assessment and application process without further notice to me.',
        'I agree that this agreement is not a loan but a purchase of my future receipts and receivables. I acknowledge and understand my rights and responsibilities under this agreement, the Uniform Commercial Code (UCC) and all applicable law.',
        `${layout.shortName} enters into this agreement based on the understanding that the funds advanced to me through this purchase will not be used for personal, family, or household purposes. I confirm that I am a valid business, entering into this Agreement solely for business purposes, and not as a consumer for personal, family, or household purposes. I acknowledge and agree that I am not entitled to the rights and protections granted to consumers under federal and state laws pertaining to consumer loans. Furthermore, I authorize ${layout.shortName}, along with its parents, directors, shareholders, collection agents, attorneys, agents, and employees, to contact me via text, telephone call, mail, or email regarding any status updates or collection attempts related to this contract or any outstanding debt I may have with ${layout.shortName}.`,
        'In the event of a default, my clients may receive UCC 9-406 notices.',
        `Regardless of any collection action taken by ${layout.shortName} or its representatives or agents, ${layout.shortName} reserves the right to continue debiting payments from my account until the outstanding balance, along with applicable fees, is paid in full.`,
        `I have had ample opportunity to consult with an attorney of my choosing regarding the terms and clauses of this agreement. ${layout.shortName} has advised me to seek legal counsel, and I confirm that I have taken the time to review and understand all clauses and terms of this agreement. Specifically, I am aware of my rights and responsibilities under the "reconciliation clause" and understand that I have the right to inform ${layout.shortName} and provide notification if any adjustments need to be made to the "Initial Estimated Remittance Amount" as outlined in this agreement.`,
        `I acknowledge and agree that ${layout.shortName} may contact my clients, payment processors, or Accounts/Account Debtors (as defined under the UCC) at any time (before, during and after this funding) to verify records, accounting or my standing. I further indemnify and hold ${layout.shortName} harmless from any claims, including but not limited to lost revenue or damaged relationships, arising from such communications.`
      ], 54, y, 520, fonts.Helvetica, 9.6, { leading: 11.5, paraGap: 4 });
      y += 8;
      y = drawWrappedBlock(page, pageHeight, 'I, the undersigned acknowledge that I have read, comprehended, and accepted all the provisions stated above, which are also described in detail within the pages of this document.', 52, y, 518, fonts.TimesRoman, 10.5, 12.5);
      y += 24;
      drawTopRule(page, pageHeight, 64, y, 200, 0.85);
      drawTopRule(page, pageHeight, 324, y, 180, 0.85);
      drawTopText(page, pageHeight, 'Signature', 66, y + 6, 10, fonts.TimesRoman);
      drawTopText(page, pageHeight, 'Date', 326, y + 6, 10, fonts.TimesRoman);
      return;
    }

    if (pageIsInGroup(pageNum, 'agreementSellerTable')) {
      const agreementPartyText = sellerPartyText;
      const tableRegion = { x: 42, yTop: 124, width: 540, height: 222 };
      clearRegionTop(page, pageHeight, tableRegion, 1.8);

      const ink = PDFLib.rgb(0, 0, 0);
      const labelShade = PDFLib.rgb(0.93, 0.93, 0.93);
      const white = PDFLib.rgb(1, 1, 1);
      const tableX = 48;
      const tableY = 126;
      const tableW = 526;
      const labelW = 82;
      const drawCellBox = (x, yTop, width, height, fill = white, borderWidth = 0.55) => {
        page.drawRectangle({
          x,
          y: pageHeight - (yTop + height),
          width,
          height,
          color: fill,
          borderColor: ink,
          borderWidth,
        });
      };
      const drawInfoRow = (label, value, yTop, height, opts = {}) => {
        drawCellBox(tableX, yTop, labelW, height, labelShade, 0.55);
        drawCellBox(tableX + labelW, yTop, tableW - labelW, height, white, 0.55);
        drawFittedWrappedBlock(page, pageHeight, label, tableX + 6, yTop + 7, labelW - 12, height - 12, fonts.HelveticaBold, {
          startSize: opts.labelSize || 8.6,
          minSize: 7.0,
          leadingFactor: 1.05,
          maxLines: opts.labelLines || 2,
        });
        drawFittedWrappedBlock(page, pageHeight, value || '', tableX + labelW + 8, yTop + 7, tableW - labelW - 14, height - 12, opts.valueFont || fonts.Helvetica, {
          startSize: opts.valueSize || 8.9,
          minSize: opts.minSize || 7.1,
          leadingFactor: 1.12,
          maxLines: opts.valueLines || 2,
        });
      };
      const drawEntityRow = (yTop, height) => {
        const typeLabelW = 112;
        const typeValueW = 204;
        const stateLabelW = 78;
        const stateValueW = tableW - typeLabelW - typeValueW - stateLabelW;
        let x = tableX;
        drawCellBox(x, yTop, typeLabelW, height, labelShade, 0.55);
        drawFittedWrappedBlock(page, pageHeight, 'Type of Business Entity', x + 6, yTop + 6, typeLabelW - 12, height - 10, fonts.HelveticaBold, {
          startSize: 8.55,
          minSize: 7.0,
          leadingFactor: 1.03,
          maxLines: 3,
        });
        x += typeLabelW;
        drawCellBox(x, yTop, typeValueW, height, white, 0.55);
        drawFittedWrappedBlock(page, pageHeight, String(formValues.entity_type || '').trim(), x + 8, yTop + 10, typeValueW - 14, height - 14, fonts.HelveticaBold, {
          startSize: 9.2,
          minSize: 7.4,
          leadingFactor: 1.08,
          maxLines: 2,
        });
        x += typeValueW;
        drawCellBox(x, yTop, stateLabelW, height, labelShade, 0.55);
        drawFittedWrappedBlock(page, pageHeight, 'Entity State', x + 6, yTop + 8, stateLabelW - 12, height - 12, fonts.HelveticaBold, {
          startSize: 8.55,
          minSize: 7.0,
          leadingFactor: 1.05,
          maxLines: 2,
        });
        x += stateLabelW;
        drawCellBox(x, yTop, stateValueW, height, white, 0.55);
        drawCenteredTopText(page, pageHeight, String(formValues.entity_state || '').trim(), x + (stateValueW / 2), yTop + 12, 9.4, fonts.HelveticaBold);
      };

      drawInfoRow('Seller:', agreementPartyText, tableY, 38, { valueSize: 9.0, minSize: 7.0, valueLines: 2 });
      drawInfoRow('D/B/A', dbaOnlyText, tableY + 38, 34, { valueSize: 8.8, minSize: 6.9, valueLines: 2 });
      drawEntityRow(tableY + 72, 40);
      drawInfoRow('Physical Address', addressText, tableY + 112, 26, { valueSize: 8.35, valueLines: 1 });
      drawInfoRow('Mailing Address', String(formValues.mailing_address || formValues.address || '').trim(), tableY + 138, 26, { valueSize: 8.35, valueLines: 1 });
      drawInfoRow('EIN#', String(formValues.ein || '').trim(), tableY + 164, 22, { valueSize: 8.35, valueLines: 1 });
      drawInfoRow('Email', String(formValues.email || '').trim(), tableY + 186, 22, { valueSize: 8.1, minSize: 6.7, valueLines: 1 });
      return;
    }

    if (pageIsInGroup(pageNum, 'guarantyOpening')) {
      const region = { x: 46, yTop: 62, width: 534, height: 104 };
      clearRegionTop(page, pageHeight, region, 2.5);
      const intro = `This PERSONAL GUARANTY OF PERFORMANCE is entered into in conjunction with that certain AGREEMENT FOR PURCHASE AND SALE OF FUTURE RECEIVABLES (hereinafter "PSFRA", which together with the SELLER AGREEMENT TERMS AND CONDITIONS, the SECURITY AGREEMENT, the PERSONAL GUARANTY(S) OF PERFORMANCE, the POWER OF ATTORNEY, APPENDIX A: THE FEE STRUCTURE and any appendices and addenda hereto and executed in conjunction herewith, shall be collectively referred to as the "Agreement"), made at the specific insistence and request of ${sellerPartyText} ("Seller") on ${dateText} and made within the State of New York, County of Nassau, by and between ${layout.companyName}, mailing address at ${layout.guarantyOffice} (the "Company"), and Seller, having an office at ${addressText}.`;
      drawFittedWrappedBlock(page, pageHeight, intro, 52, 76, 522, 88, fonts.Helvetica, {
        startSize: 9.15,
        minSize: 7.8,
        leadingFactor: 1.12,
        maxLines: 9,
      });
      return;
    }

    if (pageIsInGroup(pageNum, 'securityTop')) {
      const region = { x: 46, yTop: 58, width: 534, height: 198 };
      clearRegionTop(page, pageHeight, region, 1.2);
      const drawSecurityField = (label, value, x, yTop, width, height, opts = {}) => {
        const labelSize = opts.labelSize ?? 8.15;
        const valueSize = opts.valueSize ?? 8.75;
        const labelFont = opts.labelFont || fonts.HelveticaBold;
        const valueFont = opts.valueFont || fonts.Helvetica;
        drawTopText(page, pageHeight, label, x, yTop, labelSize, labelFont);
        drawFittedWrappedBlock(
          page,
          pageHeight,
          value || '',
          x,
          yTop + 10,
          width,
          height - 12,
          valueFont,
          {
            startSize: valueSize,
            minSize: opts.minSize ?? 6.4,
            leadingFactor: opts.leadingFactor ?? 1.12,
            maxLines: opts.maxLines ?? 2,
          }
        );
      };

      drawTopText(page, pageHeight, 'SECURITY AGREEMENT PARTY INFORMATION', 54, 62, 10.6, fonts.HelveticaBold);
      drawTopRule(page, pageHeight, 54, 78, 500, 0.75);
      const leftX = 56;
      const rightX = 318;
      const colW = 236;
      drawSecurityField(`Seller's Legal Name ("Seller")`, sellerPartyText, leftX, 92, 246, 58, {
        valueSize: 8.5,
        minSize: 6.4,
        maxLines: 3,
      });
      drawSecurityField(`Guarantor(s)' Legal Name(s)`, ownerDisplayText, rightX, 92, colW, 58, {
        valueSize: 8.5,
        minSize: 6.4,
        maxLines: 3,
      });
      drawTopRule(page, pageHeight, 54, 154, 500, 0.45);
      drawSecurityField('D/B/A', dbaOnlyText, leftX, 168, 246, 48, {
        valueSize: 8.2,
        minSize: 6.15,
        maxLines: 3,
      });
      drawSecurityField('Federal TAX ID#', String(formValues.ein || '').trim(), rightX, 168, 96, 34, {
        valueSize: 8.4,
        maxLines: 1,
      });
      drawSecurityField('Social Security#', ssnText, 432, 168, 122, 34, {
        valueSize: 8.4,
        minSize: 6.1,
        maxLines: 1,
      });
      drawSecurityField('Physical Address', addressText, leftX, 218, 300, 34, {
        valueSize: 8.55,
        minSize: 6.25,
        maxLines: 2,
      });
      drawSecurityField('Personal Guarantor(s)', ownerDisplayText, 382, 218, 172, 34, {
        valueSize: 8.25,
        minSize: 6.1,
        maxLines: 2,
      });
      return;
    }

    if (pageIsInGroup(pageNum, 'powerOfAttorneyOpening')) {
      const region = { x: 38, yTop: 34, width: 556, height: 700 };
      clearRegionTop(page, pageHeight, region, 2.5);
      drawCenteredTopText(page, pageHeight, 'POWER OF ATTORNEY', page.getSize().width / 2, 44, 15.8, fonts.HelveticaBold);
      drawTopRule(page, pageHeight, 218, 62, 176, 0.9);
      const intro = `KNOWN ALL BY THESE PRESENTS that I, ${owner1Text}, principal and/or sole proprietor of ${sellerPartyText}, doing business as ${dbaOnlyText}, at ${addressText} (hereinafter 'Grantor'), does hereby appoint ${layout.companyName}, (hereinafter, "${layout.shortName}") as my true and lawful attorney in fact:`;
      const ownerVerb = hasSecondOwner ? 'hold' : 'holds';
      const poaItems = [
        `1. To have full power and authority to direct any Merchant Processor being used by Grantor to make payments to ${layout.shortName} as contemplated under the Agreement dated ${dateText} (the "Agreement") between Grantor and ${layout.shortName};`,
        `2. To have full power and authority to direct any Merchant Processor being used by Grantor to direct the entirety of Grantor's credit card receivables to ${layout.shortName} in order to satisfy amounts due to ${layout.shortName} under the Agreement;`,
        `3. To have full power and authority to direct the Grantor’s Bank and any and all other Banks in which Grantor or ${ownerDisplayText} ${ownerVerb} an account to direct payment(s) to ${layout.shortName} as contemplated under the ACH/ADF Authorization Agreement between Grantor and ${layout.shortName};`,
        `4. To communicate with Grantor’s Bank and any and all other Banks to obtain information regarding the business accounts of Grantor, including without limitation, obtaining balances, account numbers, and copies of all statements and/or banking transactions;`,
        `5. To enter into, make, sign, execute, endorse, accept, and deliver any and all documents, agreements, contracts, or other writings, or to perform any other act, deed, matter, or thing to effectuate the intent of the Agreement dated ${dateText} between Grantor and ${layout.shortName};`,
        `6. To obtain and adjust insurance at ${layout.shortName}'s expense;`,
        '7. To withdraw any monies held on account with any debt settlement companies;',
        `8. To receive, endorse, negotiate, and collect any checks, notes, drafts, instruments, documents, or chattel paper in connection any amounts due to ${layout.shortName} as contemplated under the Agreement dated ${dateText} (the "Agreement") between Grantor and ${layout.shortName};`,
        '9. To cancel, modify, repudiate, or terminate any agreement(s) with any vendor, consultant, or service provider of Grantor;',
        `10. To sign Grantor's name on any invoice, bill of lading, or assignment directing customers or account debtors to make payment directly to ${layout.shortName};`,
        '11. To prepare, execute, file, and terminate, on behalf of the Grantor, mechanic’s liens and all related notices and documents necessary to establish, perfect, foreclose, and release any lien for labor performed or materials furnished to improve real property.',
        `12. To execute any lien waiver or general waiver, including but not limited to a mechanic’s lien waiver, on behalf of the Grantor. The Grantor hereby agrees that the signature of ${layout.shortName} shall constitute a valid and binding waiver, sufficient to compel any Account Debtor (as defined by the UCC) to remit payment on Accounts that were contingent upon the Grantor’s signed waiver.`,
        '13. To file any claims or take any action or institute any proceeding which Company may deem necessary for the collection of any of the undelivered Purchased Amount from the Collateral, or otherwise to enforce its rights with respect to payment of the Purchased Amount along with any applicable fees;',
        "14. To create and negotiate a check or draft in Seller's name utilizing any account information on file in satisfaction of Seller's obligations to Company, Company's designee, or Company's nominee; and",
        "15. To institute a wire transfer of funds from Seller's deposit account(s) to Company, Company's designee, or Company's nominee.",
      ];
      const contentX = 52;
      const contentWidth = 520;
      const topY = 82;
      const bottomLimit = 734;
      const measureBody = (size) => {
        const leading = size * 1.16;
        const introLines = wrapToWidth(intro, fonts.Helvetica, size, contentWidth);
        let total = introLines.length * leading + 18;
        poaItems.forEach(item => {
          total += wrapToWidth(item, fonts.Helvetica, size, contentWidth - 8).length * leading + 3.5;
        });
        return total;
      };
      let bodySize = 9.55;
      while (bodySize > 8.1 && topY + measureBody(bodySize) > bottomLimit) {
        bodySize -= 0.1;
      }
      const leading = bodySize * 1.16;
      let y = drawWrappedBlock(page, pageHeight, intro, contentX, topY, contentWidth, fonts.Helvetica, bodySize, leading);
      y += 16;
      poaItems.forEach((item, idx) => {
        y = drawWrappedBlock(page, pageHeight, item, contentX + 6, y, contentWidth - 6, fonts.Helvetica, bodySize, leading);
        y += idx === 5 ? 5 : 3.5;
      });
      drawInitialsFooter(page, pageHeight, fonts);
      return;
    }

    if (pageIsInGroup(pageNum, 'powerOfAttorneyExecution')) {
      const region = { x: 46, yTop: 116, width: 534, height: 210 };
      clearRegionTop(page, pageHeight, region, 2.5);
      let y = 126;
      const witnessText = `IN WITNESS WHEREOF, the said ${sellerPartyText} has caused this instrument to be signed, sealed and acknowledged by its duly authorized qualified officer, this date ${dateText}. KNOW ALL BY THESE PRESENTS:`;
      y = drawWrappedBlock(page, pageHeight, witnessText, 52, y, 522, fonts.TimesRoman, 10.75, 12.75);
      renderSellerPanels(
        { x: 68, yTop: Math.max(y + 16, 226), width: 472, height: 166 },
        {
          leftHeading: 'SELLER #1',
          rightHeading: 'SELLER #2',
          companyText: sellerPartyText,
          companySize: 9.25,
          companyLeading: 10.5,
          companyFont: fonts.TimesRoman,
        }
      );
      return;
    }

    if (pageIsInGroup(pageNum, 'noaAssignment')) {
      clearRectTop(page, pageHeight, 0, 0, page.getSize().width, pageHeight, 0);
      const pageWidth = page.getSize().width;
      const ink = PDFLib.rgb(0, 0, 0);
      const shade = PDFLib.rgb(0.92, 0.92, 0.92);
      const softShade = PDFLib.rgb(0.975, 0.975, 0.975);
      const drawCell = (label, value, x, yTop, width, height, opts = {}) => {
        page.drawRectangle({
          x,
          y: pageHeight - (yTop + height),
          width,
          height,
          color: PDFLib.rgb(1, 1, 1),
          borderColor: ink,
          borderWidth: 0.65,
        });
        page.drawRectangle({
          x,
          y: pageHeight - (yTop + 17),
          width,
          height: 17,
          color: shade,
          borderWidth: 0,
        });
        drawTopText(page, pageHeight, label, x + 7, yTop + 5, 7.7, fonts.HelveticaBold);
        drawFittedWrappedBlock(page, pageHeight, value || '', x + 7, yTop + 23, width - 14, height - 27, opts.font || fonts.TimesRoman, {
          startSize: opts.startSize || 9.2,
          minSize: opts.minSize || 6.8,
          leadingFactor: 1.09,
          maxLines: opts.maxLines || 3,
        });
      };

      drawTopRule(page, pageHeight, 52, 40, pageWidth - 104, 1.25);
      drawCenteredTopText(page, pageHeight, 'NOTICE OF ASSIGNMENT OF ACCOUNTS RECEIVABLE', pageWidth / 2, 56, 15.8, fonts.TimesBold);
      drawCenteredTopText(page, pageHeight, 'Uniform Commercial Code Section 9-406(c)', pageWidth / 2, 78, 10.4, fonts.TimesRoman);
      drawTopRule(page, pageHeight, 52, 96, pageWidth - 104, 0.85);

      const panelX = 58;
      const panelY = 112;
      const panelW = 496;
      page.drawRectangle({
        x: panelX,
        y: pageHeight - (panelY + 170),
        width: panelW,
        height: 170,
        color: softShade,
        borderColor: ink,
        borderWidth: 0.9,
      });
      page.drawRectangle({
        x: panelX,
        y: pageHeight - (panelY + 22),
        width: panelW,
        height: 22,
        color: shade,
        borderWidth: 0,
      });
      drawCenteredTopText(page, pageHeight, 'ASSIGNMENT NOTICE RECORD', panelX + (panelW / 2), panelY + 6, 9.2, fonts.HelveticaBold);
      const cellY = panelY + 22;
      const cellW = panelW / 2;
      drawCell('SELLER', businessOnlyText, panelX, cellY, cellW, 48, { font: fonts.TimesBold, startSize: 9.4, maxLines: 3 });
      drawCell('OWNER / GUARANTOR(S)', ownerAmpDisplayText, panelX + cellW, cellY, cellW, 48, { font: fonts.TimesBold, startSize: 9.4, maxLines: 3 });
      drawCell('D/B/A', dbaOnlyText, panelX, cellY + 48, cellW, 48, { startSize: 8.8, maxLines: 3 });
      drawCell('BUSINESS ADDRESS', addressText, panelX + cellW, cellY + 48, cellW, 48, { startSize: 8.8, maxLines: 3 });
      drawCell('SECURED PARTY', layout.companyName, panelX, cellY + 96, cellW, 52, { font: fonts.TimesBold, startSize: 9.6, maxLines: 2 });
      drawCell('NOTICE AUTHORITY', 'Uniform Commercial Code Section 9-406(c)', panelX + cellW, cellY + 96, cellW, 52, { startSize: 9.0, maxLines: 2 });

      let y = 312;
      drawTopText(page, pageHeight, 'TO WHOM IT MAY CONCERN:', 72, y, 11.2, fonts.TimesBold);
      y += 28;
      drawTopText(page, pageHeight, 'Re:', 96, y, 11, fonts.TimesRoman);
      drawTopText(page, pageHeight, 'Assignment of Accounts Receivable', 134, y, 11, fonts.TimesBold);
      drawTopRule(page, pageHeight, 134, y + 12, 184, 0.8);
      y += 32;
      drawTopText(page, pageHeight, 'Ladies and Gentlemen:', 72, y, 11, fonts.TimesRoman);
      y += 27;
      y = drawWrappedBlock(
        page,
        pageHeight,
        `This letter will confirm that the undersigned has assigned its present and future accounts receivable to ${layout.companyName} (the “Secured Party”), to whom all payments must be made, and shall constitute “reasonable proof that the assignment has been made” as that term is used in Section 9-406(c) of the Uniform Commercial Code.`,
        96,
        y,
        432,
        fonts.TimesRoman,
        10.8,
        12.8
      );
      y += 18;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'You are irrevocably authorized and requested to rely on a photocopy or facsimile of this letter in lieu of the original. This letter supersedes any prior contrary communication which you may have received concerning the above, and may be rescinded only by the Secured Party in writing. Thus, it may not be rescinded by us.',
        96,
        y,
        432,
        fonts.TimesRoman,
        10.8,
        12.8
      );
      drawTopText(page, pageHeight, 'Executed by Seller:', 72, 548, 10.8, fonts.TimesBold);
      renderSellerPanels(
        { x: 76, yTop: 574, width: 460, height: 146 },
        {}
      );
      drawInitialsFooter(page, pageHeight, fonts);
      return;
    }

    if (pageIsInGroup(pageNum, 'scheduleAExecution')) {
      let y = 78;
      drawTopText(page, pageHeight, '6.', 62, y, 11.2, fonts.TimesBold);
      y = drawWrappedBlock(
        page,
        pageHeight,
        'The execution of this Schedule A by any one listed Merchant Entity constitutes agreement by all listed entities;',
        92,
        y,
        462,
        fonts.TimesRoman,
        11.2,
        13.2
      );
      y += 16;
      drawTopText(page, pageHeight, '7.', 62, y, 11.2, fonts.TimesBold);
      y = drawWrappedBlock(
        page,
        pageHeight,
        'Electronic signatures on this Schedule A and the Agreement are valid and enforceable pursuant to the ESIGN Act and UETA, and shall carry the full legal force of a handwritten signature.',
        92,
        y,
        462,
        fonts.TimesRoman,
        11.2,
        13.2
      );
      y += 22;
      drawTopText(page, pageHeight, 'Merchant Entity Table', 52, y, 15.5, fonts.TimesBold);

      const inferScheduleAEntityType = (biz) => /(^|\s)DBA($|\s)/i.test(String(biz || '')) ? 'DBA' : 'LLC/Corp';
      const rows = [
        { number: '1', biz: formValues.biz_1 || '', ein: formValues.ein_1 || '', entityType: (formValues.biz_1 || '').trim() ? inferScheduleAEntityType(formValues.biz_1) : '', state: formValues.es_1 || '', address: formValues.address_1 || '' },
        { number: '2', biz: formValues.biz_2 || '', ein: formValues.ein_2 || '', entityType: (formValues.biz_2 || '').trim() ? inferScheduleAEntityType(formValues.biz_2) : '', state: formValues.es_2 || '', address: formValues.address_2 || '' },
        { number: '3', biz: formValues.biz_3 || '', ein: formValues.ein_3 || '', entityType: (formValues.biz_3 || '').trim() ? inferScheduleAEntityType(formValues.biz_3) : '', state: formValues.es_3 || '', address: formValues.address_3 || '' },
      ];
      const tableX = 43;
      const tableY = 174;
      const headerHeight = 21;
      const rowHeight = 42;
      const colWidths = [18, 170, 58, 60, 34, 186];
      const tableWidth = colWidths.reduce((sum, width) => sum + width, 0);
      const tableHeight = headerHeight + (rowHeight * rows.length);
      const drawTableCell = (x, yTop, width, height) => {
        page.drawRectangle({
          x,
          y: pageHeight - (yTop + height),
          width,
          height,
          color: PDFLib.rgb(1, 1, 1),
          borderColor: PDFLib.rgb(0, 0, 0),
          borderWidth: 0.6,
        });
      };

      let cursorX = tableX;
      const headerLabels = ['#', 'Legal Business Name', 'EIN', 'Entity Type', 'State', 'Business Address'];
      headerLabels.forEach((label, idx) => {
        drawTableCell(cursorX, tableY, colWidths[idx], headerHeight);
        drawCenteredTopText(
          page,
          pageHeight,
          label,
          cursorX + (colWidths[idx] / 2),
          tableY + 5,
          idx === 1 ? 7.2 : 7.25,
          fonts.TimesBold
        );
        cursorX += colWidths[idx];
      });

      rows.forEach((row, idx) => {
        const rowY = tableY + headerHeight + (idx * rowHeight);
        let x = tableX;
        const values = [row.number, row.biz, row.ein, row.entityType, row.state, row.address];
        values.forEach((value, colIdx) => {
          const width = colWidths[colIdx];
          drawTableCell(x, rowY, width, rowHeight);
          if (colIdx === 0 || colIdx === 4) {
            drawCenteredTopText(page, pageHeight, value, x + (width / 2), rowY + 15, 7.1, fonts.Helvetica);
          } else if (colIdx === 2) {
            drawFittedWrappedBlock(page, pageHeight, value, x + 4, rowY + 14, width - 8, rowHeight - 16, fonts.Helvetica, {
              startSize: 6.9, minSize: 5.6, leadingFactor: 1.05, maxLines: 1,
            });
          } else if (colIdx === 3) {
            drawFittedWrappedBlock(page, pageHeight, value, x + 4, rowY + 8, width - 8, rowHeight - 10, fonts.Helvetica, {
              startSize: 6.9, minSize: 5.8, leadingFactor: 1.08, maxLines: 2,
            });
          } else {
            drawFittedWrappedBlock(page, pageHeight, value, x + 4, rowY + 7, width - 8, rowHeight - 9, fonts.Helvetica, {
              startSize: colIdx === 1 ? 7.0 : 6.45,
              minSize: colIdx === 1 ? 5.8 : 5.35,
              leadingFactor: 1.08,
              maxLines: colIdx === 1 ? 3 : 4,
            });
          }
          x += width;
        });
      });
      y = tableY + tableHeight + 22;
      y = drawWrappedBlock(
        page,
        pageHeight,
        'By signing below, each Merchant Entity affirms it has reviewed and agreed to all terms of the Agreement and confirms it is fully bound by all referenced and incorporated documents.',
        52,
        y,
        520,
        fonts.TimesRoman,
        11.2,
        13.3
      );
      drawTopText(page, pageHeight, 'Signature(s)', 52, Math.max(y + 24, 372), 15.5, fonts.TimesBold);
      renderSellerPanels(
        { x: 76, yTop: 462, width: 460, height: 104 },
        {
          leftHeading: 'SELLER #1',
          rightHeading: 'SELLER #2',
        }
      );
      renderOwnerPanels(
        { x: 76, yTop: 606, width: 460, height: 104 },
        {
          leftHeading: 'OWNER/GUARANTOR #1',
          rightHeading: 'OWNER/GUARANTOR #2',
        }
      );
      drawInitialsFooter(page, pageHeight, fonts);
      return;
    }

    if (pageIsInGroup(pageNum, 'declarationOpening')) {
      const region = { x: 44, yTop: 72, width: 538, height: 108 };
      clearRegionTop(page, pageHeight, region, 2.5);
      const intro = `This Declaration is made and affirmed by the undersigned on behalf of themselves and ${sellerPartyText} (collectively, the "Merchant"), in connection with a funding transaction with ${layout.companyName} (the "Company").`;
      drawWrappedBlock(page, pageHeight, intro, 50, 82, 524, fonts.Helvetica, 10.1, 12.25);
      return;
    }

    if (pageIsInGroup(pageNum, 'addendumOpening')) {
      const region = { x: 44, yTop: 58, width: 536, height: 110 };
      clearRegionTop(page, pageHeight, region, 3);
      let y = 68;
      const opening = `This Addendum ("Addendum") is entered into as of ${dateText} by and between ${layout.companyName}, with a principal place of business at ${layout.principalOffice} ("Company"), and ${sellerPartyText}, with a principal place of business at ${addressText} ("Seller").`;
      y = drawWrappedBlock(page, pageHeight, opening, 52, y, 522, fonts.Helvetica, 10.5, 12.5);
      y += 8;
      const followOn = `This Addendum modifies and supplements the AGREEMENT FOR PURCHASE AND SALE OF FUTURE RECEIVABLES between the Company and the Seller, dated ${dateText} and is incorporated into the Agreement by reference.`;
      drawWrappedBlock(page, pageHeight, followOn, 52, y, 522, fonts.Helvetica, 10.5, 12.5);
      return;
    }

    if (pageIsInGroup(pageNum, 'addendumExecution')) {
      clearRegionTop(page, pageHeight, { x: 52, yTop: 152, width: 508, height: 308 }, 3);
      renderSellerPanels(
        { x: 66, yTop: 196, width: 480, height: 122 },
        {
          leftHeading: 'SELLER #1',
          rightHeading: 'SELLER #2',
          leftSubheading: 'Individually, and on behalf Seller',
          rightSubheading: 'Individually, and on behalf Seller',
        }
      );
      renderOwnerPanels(
        { x: 66, yTop: 344, width: 480, height: 122 },
        {
          leftHeading: 'OWNER/GUARANTOR #1',
          rightHeading: 'OWNER/GUARANTOR #2',
        }
      );
      return;
    }

    if (pageIsInGroup(pageNum, 'isoOpening')) {
      renderIsoOpeningParagraph(page, pageNum, formValues, fonts, includeSchedA, pageHeight);
      return;
    }

    if (pageIsInGroup(pageNum, 'isoExecution')) {
      renderSellerPanels({ x: 72, yTop: 500, width: 392, height: 138 }, { leftHeading: 'Seller: #1', rightHeading: 'Seller: #2' });
      return;
    }

    if (renderAdaptiveExecutionLayout()) return;
  }

  function renderIsoOpeningParagraph(page, pageNum, formValues, fonts, includeSchedA, pageHeight) {
    const rects = ISO_OPENING_RECTS_BY_PAGE[pageNum];
    if (!rects) return false;
    const dateText = formatDate(formValues.date || '');
    const funder = cfg.FUNDERS[formValues.funder];
    const sellerParty = includeSchedA ? getBizSlotText(formValues, true) : buildSellerShortText(formValues);
    const spans = [
      { font: 'TimesRoman', text: `This Addendum (“Addendum”) is entered into as of ${dateText}, by and between ` },
      { font: 'TimesBold',  text: `${funder.label} ` },
      { font: 'TimesRoman', text: `(“Company” or “${funder.code === 'ICC' ? 'ICC' : 'ESE'}”) and ` },
      { font: 'TimesBold',  text: `${sellerParty} ` },
      { font: 'TimesRoman', text: `(“Seller”). This Addendum is incorporated into and forms a material part of the Agreement for Purchase and Sale of Future Receivables and all related documents executed in connection therewith (collectively, the “Agreement”).` },
    ];

    for (const r of rects) {
      const pad = 0.5;
      const yPdfBottom = pageHeight - r.y1_pm;
      const yPdfTop = pageHeight - r.y0_pm;
      page.drawRectangle({
        x: r.x0 - pad,
        y: yPdfBottom - pad,
        width: (r.x1 - r.x0) + 2 * pad,
        height: (yPdfTop - yPdfBottom) + 2 * pad,
        color: PDFLib.rgb(1, 1, 1),
        borderWidth: 0,
      });
    }

    const lines = layoutRichText(spans, fonts, 12, rects);
    lines.forEach((line, i) => {
      const r = rects[i];
      const yPdfBottom = pageHeight - r.y1_pm;
      const yPdfTop = pageHeight - r.y0_pm;
      const baseline = yPdfBottom + (yPdfTop - yPdfBottom) * 0.2;
      line.forEach(token => {
        page.drawText(token.text, {
          x: token.x,
          y: baseline,
          size: 12,
          font: token.font,
          color: PDFLib.rgb(0, 0, 0),
        });
      });
    });
    return true;
  }

  function drawDerivedDisclosureFields(pageNum, page, derivedValues, fonts) {
    const fields = DISCLOSURE_DERIVED_FIELDS[pageNum];
    if (!fields) return;
    for (const field of fields) {
      const value = derivedValues[field.key];
      if (!value) continue;
      const font = fonts[field.font] || fonts.TimesRoman || fonts.Helvetica;
      let size = field.size;
      let textWidth = font.widthOfTextAtSize(String(value), size);
      while (textWidth > field.avail_w - 0.5 && size > 6) {
        size -= 0.25;
        textWidth = font.widthOfTextAtSize(String(value), size);
      }
      page.drawRectangle({
        x: field.x - 1,
        y: field.y_bot - 1,
        width: field.avail_w + 2,
        height: 14,
        color: PDFLib.rgb(1, 1, 1),
        borderWidth: 0,
      });
      page.drawText(String(value), {
        x: field.x,
        y: field.baseline,
        size,
        font,
        color: PDFLib.rgb(0, 0, 0),
      });
    }
  }

  /**
   * Render one composite slot on a page. Returns the names of placeholders
   * that were rendered as part of this slot (so the simple-placeholder
   * pass can skip them).
   */
  function renderCompositeSlot(page, pageNum, slot, phValues, formValues, fonts, includeSchedA, pageHeight) {
    // 1. Build the text to render.
    //    Try short-form substitution first (Seller-recital case), then fall back.
    const biz = (formValues.business_name || '').trim();
    const dba = (formValues.dba_name || '').trim();
    const bizOrDba = dba || biz;
    const ownerPair = getOwnerClauseText(formValues);
    const ownerAmpPair = getOwnerAmpClauseText(formValues);

    // Identify if this slot's template contains the Schedule A recital.
    const hasScheduleARecital = SCHEDULE_A_RECITAL_RE.test(slot.template);

    // Substitute placeholders into the template
    let templateForRender = slot.template;
    if (slot.template === '{{s1}} and {{s2}}') {
      templateForRender = ownerPair;
    } else if (slot.template === '{{s1}} & {{s2}}') {
      templateForRender = ownerAmpPair;
    }

    if (hasScheduleARecital) {
      // Per Juan's rule: when the entity+owner fits in the available width,
      // use the short form "BIZ and OWNER DBA BIZ_OR_DBA". When it doesn't,
      // fall back to the long-form Schedule A recital. When NoSchedA, never
      // use long form — always short or bare biz.
      //
      // Apply this rule to BOTH {{biz}}-led slots (Seller cell) and
      // {{dba}}-led slots (D/B/A cell), matching the contract girl's manual.
      const shortReplacement = ownerPair ? ` ${ownerPair} DBA ${bizOrDba}` : '';
      const shortTail = /,\s*and each additional/i.test(slot.template) ? ' ,' : '';
      const stripped = slot.template.replace(SCHEDULE_A_RECITAL_RE, '');
      // Insert the short replacement after whichever lead placeholder appears.
      let shortCandidateBase;
      if (/\{\{biz\}\}/.test(stripped)) {
        shortCandidateBase = stripped.replace(/(\{\{biz\}\})/, '$1' + shortReplacement + shortTail);
      } else if (/\{\{dba\}\}/.test(stripped)) {
        shortCandidateBase = stripped.replace(/(\{\{dba\}\})/, '$1' + shortReplacement + shortTail);
      } else {
        shortCandidateBase = stripped;
      }
      const shortRendered = substitutePlaceholders(shortCandidateBase, phValues);

      // Pick which form to use based on width fit.
      const font = fonts[slot.base_font] || fonts.Helvetica;
      const shortFits = fitTextToSlot(
        shortRendered, font, slot.base_size, slot.line_rects, 6
      ).fit;

      if (includeSchedA) {
        // SchedA is being attached: long form is required to reference it.
        templateForRender = slot.template;
      } else if (shortFits) {
        // No SchedA; use short form when it fits the available width.
        templateForRender = shortCandidateBase;
      } else {
        // No SchedA and short form doesn't fit: keep the full short-form
        // legal text and let the page-level override or shrink-to-fit logic
        // handle the layout. Never silently drop party language.
        templateForRender = shortCandidateBase;
      }
    }

    // Now substitute placeholders in the chosen template
    const finalText = substitutePlaceholders(templateForRender, phValues).trim();
    let effectiveLineRects = slot.line_rects || [];
    if (
      !includeSchedA &&
      (
        hasScheduleARecital ||
        slot.template === '{{s1}} and {{s2}}' ||
        slot.template === '{{s1}} & {{s2}}'
      )
    ) {
      effectiveLineRects = expandedLineRects(slot);
    }

    // 2. White-rect each line_rect to clear the original text, INCLUDING the
    //    placeholder slot itself and the literal followers.
    for (const r of effectiveLineRects) {
      const pad = 0.5;
      const yPdfBottom = pageHeight - r.y1_pm;
      const yPdfTop = pageHeight - r.y0_pm;
      page.drawRectangle({
        x: r.x0 - pad,
        y: yPdfBottom - pad,
        width: (r.x1 - r.x0) + 2 * pad,
        height: (yPdfTop - yPdfBottom) + 2 * pad,
        color: PDFLib.rgb(1, 1, 1),
        borderWidth: 0,
      });
    }

    // 3. If ALL placeholders in this slot resolve to empty values, leave the
    //    slot blank (the white-rect already cleared the master text). This
    //    handles the "Owner #2 column when owner_2 is empty" case — without
    //    this, the literal "/Owner" suffix would print alone.
    const allValuesEmpty = (slot.placeholder_names || []).every(name => {
      const v = phValues[name];
      return v == null || String(v).trim() === '';
    });
    if (allValuesEmpty && !([40, 93, 140].includes(pageNum) && /\{\{s2\}\}\/Owner/.test(slot.template))) {
      return slot.placeholder_names || [];
    }

    // 4. Fit the final text into the available line rects.
    if (!finalText) return slot.placeholder_names || [];
    const font = fonts[slot.base_font] || fonts.Helvetica;
    const { size, lines, lineHeight } = fitTextToSlot(
      finalText, font, slot.base_size, effectiveLineRects, 6
    );

    // 5. Draw lines into the line_rects.
    for (let i = 0; i < lines.length; i++) {
      const r = effectiveLineRects[i] || effectiveLineRects[effectiveLineRects.length - 1];
      const yPdfBottom = pageHeight - r.y1_pm;
      const yPdfTop = pageHeight - r.y0_pm;
      // Baseline position: roughly at the bottom of the rect with a small offset
      // up so descenders don't get clipped.
      const baseline = yPdfBottom + (yPdfTop - yPdfBottom) * 0.2;
      page.drawText(lines[i], {
        x: r.x0,
        y: baseline,
        size: size,
        font: font,
        color: PDFLib.rgb(0, 0, 0),
      });
    }

    // 5. Return list of placeholder names rendered (so simple-placeholder pass skips them)
    return [...new Set((slot.placeholder_names || []))];
  }

  function renderOverlayPage(page, pageNum, phValues, formValues, fonts, includeSchedA, derivedValues) {
    const pageHeight = page.getSize().height;
    let compositeFilled = 0;
    let simpleFilled = 0;
    const claimedRects = [];
    const customRegions = getCustomOverrideRegions(pageNum);
    const fullCustom = isFullCustomPage(pageNum);

    if (fullCustom) {
      const { width, height } = page.getSize();
      page.drawRectangle({
        x: 0,
        y: 0,
        width,
        height,
        color: PDFLib.rgb(1, 1, 1),
        borderWidth: 0,
      });
      renderCustomPageOverrides(
        page,
        pageNum,
        formValues,
        fonts,
        includeSchedA,
        pageHeight
      );
      return { compositeFilled, simpleFilled };
    }

    const slots = (STATE.compositeSlotsByPage && STATE.compositeSlotsByPage.get(pageNum)) || [];
    const sortedSlots = slots.slice().sort((a, b) =>
      (b.bbox.x1 - b.bbox.x0) - (a.bbox.x1 - a.bbox.x0)
    );
    for (const slot of sortedSlots) {
      const slotRegion = slotToTopRegion(slot);
      if (slotRegion && customRegions.some(region => topRegionsIntersect(slotRegion, region, 1.5))) {
        continue;
      }
      renderCompositeSlot(
        page,
        pageNum,
        slot,
        phValues,
        formValues,
        fonts,
        includeSchedA,
        pageHeight
      );
      for (const r of (slot.line_rects || [])) {
        claimedRects.push({
          x0: r.x0,
          x1: r.x1,
          y_bot: pageHeight - r.y1_pm,
          y_top: pageHeight - r.y0_pm,
        });
      }
      compositeFilled++;
    }

    const placeholders = STATE.coordsByPage.get(pageNum) || [];
    for (const ph of placeholders) {
      const phCenterX = ph.x + ph.orig_w * 0.5;
      const phCenterY = (ph.y_bot + ph.y_top) * 0.5;
      const phCenterTop = pageHeight - phCenterY;
      const customClaimed = customRegions.some(region =>
        topPointInRegion(phCenterX, phCenterTop, region, 1.5)
      );
      if (customClaimed) continue;
      const claimed = claimedRects.some(r =>
        phCenterX >= r.x0 - 0.5 && phCenterX <= r.x1 + 0.5 &&
        phCenterY >= r.y_bot - 1.5 && phCenterY <= r.y_top + 1.5
      );
      if (claimed) continue;
      const value = phValues[ph.name];
      if (value == null) continue;
      const pad = 1;
      page.drawRectangle({
        x: ph.x - pad,
        y: ph.y_bot - pad,
        width: ph.orig_w + 2 * pad,
        height: (ph.y_top - ph.y_bot) + 2 * pad,
        color: PDFLib.rgb(1, 1, 1),
        borderWidth: 0,
      });
      if (value !== '') {
        const font = fonts[ph.font] || fonts.Helvetica;
        const MIN_SIZE = 6;
        let size = ph.size;
        let textWidth = font.widthOfTextAtSize(String(value), size);
        if (textWidth > ph.avail_w + 0.5) {
          while (textWidth > ph.avail_w - 0.5 && size > MIN_SIZE) {
            size -= 0.25;
            textWidth = font.widthOfTextAtSize(String(value), size);
          }
        }
        page.drawText(String(value), {
          x: ph.x,
          y: ph.baseline,
          size,
          font,
          color: PDFLib.rgb(0, 0, 0),
        });
        simpleFilled++;
      }
    }

    drawDerivedDisclosureFields(pageNum, page, derivedValues, fonts);
    renderCustomPageOverrides(
      page,
      pageNum,
      formValues,
      fonts,
      includeSchedA,
      pageHeight
    );

    const entityType = formValues.entity_type;
    if (entityType && cfg.ENTITY_TYPE_X_MARKS) {
      const xPageNum = cfg.ENTITY_TYPE_X_MARKS.pages[formValues.funder];
      const xPos = cfg.ENTITY_TYPE_X_MARKS.positions[entityType];
      if (xPageNum === pageNum && xPos && !pageIsInGroup(pageNum, 'agreementSellerTable')) {
        page.drawText('X', {
          x: xPos.x,
          y: xPos.y,
          size: 11,
          font: fonts.HelveticaBold,
          color: PDFLib.rgb(0, 0, 0),
        });
      }
    }

    return { compositeFilled, simpleFilled };
  }

  /**
   * Compute the set of pages to copy into the main contract PDF, based on
   * the funder manifest. Returns:
   *   { mainPagesToCopy: [0-indexed page nums],
   *     wcPage: 1-indexed WC page,
   *     scheduleAPages: [titleP, contP] | null  (always set if funder has SA config),
   *     scheduleAIncluded: bool }
   */
  function buildPageManifest(funder, includeSchedA) {
    const start = funder.baseRange.start;
    const end   = funder.baseRange.end;
    const wcPage = funder.separatePages.writtenConsent[0];

    const skipSet = new Set();
    skipSet.add(wcPage);
    (funder.alwaysOmitPages || []).forEach(p => skipSet.add(p));

    // Find the SA page pair from the funder config (always exists if funder has SA)
    let scheduleAPages = null;
    for (const cond of (funder.conditionalOmitPages || [])) {
      if (cond.name === 'scheduleA') {
        scheduleAPages = cond.pages.slice();
        if (!includeSchedA) {
          cond.pages.forEach(p => skipSet.add(p));
        }
        break;
      }
    }

    const mainPagesToCopy = [];
    for (let p = start; p <= end; p++) {
      if (skipSet.has(p)) continue;
      mainPagesToCopy.push(p - 1);  // 0-indexed for pdf-lib
    }

    return {
      mainPagesToCopy,
      wcPage,
      scheduleAPages,        // always [titleP, contP], regardless of include/omit
      scheduleAIncluded: includeSchedA,
    };
  }

  /**
   * Validate Schedule A page pair by content fingerprint.
   *
   * Schedule A drift is ALWAYS fatal — regardless of whether SA is being
   * included or omitted in this generation:
   *   - When SA is INCLUDED in the output: shipping pages with wrong content
   *     would be a serious legal defect.
   *   - When SA is OMITTED from the output: drift means the configured page
   *     numbers no longer point to actual Schedule A pages, so the manifest
   *     would either silently drop the WRONG pages (losing real content) or
   *     accidentally include the actual SA pages (when omission was wanted).
   *
   * Either way is a content-correctness failure. Refuse to deliver. This
   * acts as a canary for any master template page-number drift — if SA
   * pages have shifted, very likely the WC page, always-omit pages, and
   * other page-by-number references are also wrong.
   */
  function verifyScheduleAPair(pages, fingerprints) {
    if (!pages || pages.length !== 2) return;
    const [titleP, contP] = pages;
    const titleText = STATE.pageTextCache.get(titleP) || '';
    const contText  = STATE.pageTextCache.get(contP)  || '';
    const titleOk = pageMatchesAll(titleText, fingerprints.scheduleA.titlePage);
    const contOk  = pageMatchesAll(contText,  fingerprints.scheduleA.continuationPage);
    const issues = [];
    if (!titleOk) issues.push(`Schedule A title page ${titleP} content does NOT match expected fingerprint.`);
    if (!contOk)  issues.push(`Schedule A continuation page ${contP} content does NOT match expected fingerprint.`);
    if (issues.length === 0) return;
    throw new Error(
      'Schedule A page content drift detected. The configured Schedule A page numbers no longer point to actual Schedule A pages — the master template may have changed. Refusing to deliver:\n  • ' +
      issues.join('\n  • ')
    );
  }

  /**
   * Scan PDF bytes for any raw {{...}} placeholder text in the text layer.
   * Refuses to deliver if any are found. This is a runtime safety net
   * that would catch any regression in the redaction step or any drift
   * in the master template that introduces new tokens.
   */
  async function assertNoTokenLeakage(pdfBytes, label) {
    const pdf = await pdfjsLib.getDocument({
      data: pdfBytes.slice(0),
      disableFontFace: true,
    }).promise;
    const leaks = [];
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const tc = await page.getTextContent();
      const text = tc.items.map(it => it.str).join(' ');
      const matches = text.match(/\{\{[^}]+\}\}/g);
      if (matches) {
        // Deduplicate per-page
        const uniq = Array.from(new Set(matches));
        leaks.push(`page ${p}: ${uniq.join(', ')}`);
      }
    }
    pdf.cleanup();
    if (leaks.length) {
      throw new Error(
        `Placeholder tokens leaked into ${label} PDF text layer. Refusing to deliver:\n  • ` +
        leaks.slice(0, 10).join('\n  • ') +
        (leaks.length > 10 ? `\n  • ...and ${leaks.length - 10} more` : '')
      );
    }
  }

  /**
   * Validate Written Consent page by content fingerprint. Throws if it
   * doesn't match — we don't want to silently extract the wrong page.
   */
  function verifyWrittenConsentPage(page, fingerprints) {
    const text = STATE.pageTextCache.get(page) || '';
    const fp = fingerprints.writtenConsent;
    if (!pageMatchesAll(text, fp.requiredAll) || !pageMatchesAny(text, fp.requiredAny)) {
      throw new Error(`Written Consent page ${page} content does NOT match expected fingerprint. Master template may have changed.`);
    }
  }

  async function generate() {
    const warnings = [];
    setBusy('Validating...');
    clearStatus();

    // 1. Read + normalize form values
    const rawValues = readForm();
    const formValues = normalizeFormValues(rawValues);
    const funderCode = formValues.funder;
    const funder = cfg.FUNDERS[funderCode];
    if (!funder) throw new Error('Pick a funder.');

    // 2. Required-field validation
    const missing = validateRequired(formValues);
    if (missing.length) {
      const labels = missing.map(id => {
        for (const sec of cfg.FORM_SECTIONS) {
          for (const f of sec.fields) if (f.id === id) return f.label;
        }
        return id;
      });
      throw new Error('Missing required: ' + labels.join(', '));
    }

    // 2b. Field format validation
    const formatFailures = validateFormats(formValues);
    if (formatFailures.length) {
      const lines = formatFailures.map(f => `  • ${f.label}: "${f.value}" — expected ${f.expected}`);
      throw new Error('Field format problems:\n' + lines.join('\n'));
    }

    // 2c. DBA / No DBA gate
    //   For an MCA contract, the DBA field affects operative legal text in
    //   notices, UCC § 9-406 collection language, and identity recitations.
    //   We require the operator to either (a) provide a DBA, or
    //   (b) explicitly affirm "Merchant has no DBA" (which uses the legal
    //   business name in the DBA fields). This prevents auto-fabricating
    //   factual content the operator didn't confirm.
    if (!formValues.dba_name && !formValues.no_dba) {
      throw new Error(
        'DBA Name is blank. Either:\n' +
        '  • Enter the DBA name the merchant operates under, or\n' +
        '  • Check "Merchant has no DBA" to confirm and use the legal business name in DBA positions.'
      );
    }

    // 3. Schedule A row validation (throws on partial rows)
    const includeSchedA = shouldIncludeScheduleA(formValues);

    // 4. Load master + fonts
    await loadMasterIfNeeded();
    setBusy('Loading master into editor...');
    const masterDoc = await PDFDocument.load(STATE.masterBytes.slice(0));
    const phValues = buildPlaceholderValues(formValues);
    const derivedValues = buildDerivedValues(formValues);

    // 5. Build page manifest (which pages go in main, which is WC)
    setBusy('Computing page manifest...');
    const manifest = buildPageManifest(funder, includeSchedA);

    // 6. Sanity-check WC and Schedule A page contents BEFORE slicing.
    //    Both checks throw on drift — we cannot deliver if the configured
    //    page numbers no longer match the master template. SA check acts as
    //    a canary for any page-number drift across the entire master.
    verifyWrittenConsentPage(manifest.wcPage, cfg.FINGERPRINTS);
    verifyScheduleAPair(manifest.scheduleAPages, cfg.FINGERPRINTS);

    // 7. Build the two output PDFs
    //    Main contract PDF = [Revenue Confidence Form (6 pages)] + [funder section pages]
    //    Written Consent PDF = the single WC page extracted separately
    setBusy('Building main contract PDF...');
    const mainDoc = await PDFDocument.create();
    const mainFonts = {
      Helvetica:     await mainDoc.embedFont(PDFLib.StandardFonts.Helvetica),
      HelveticaBold: await mainDoc.embedFont(PDFLib.StandardFonts.HelveticaBold),
      TimesRoman:    await mainDoc.embedFont(PDFLib.StandardFonts.TimesRoman),
      TimesBold:     await mainDoc.embedFont(PDFLib.StandardFonts.TimesRomanBold),
    };

    // Prepend the Revenue Confidence Form (6-page intro)
    const introDoc = await PDFDocument.load(STATE.introFormBytes.slice(0));
    const introPageIndices = introDoc.getPageIndices();
    const copiedIntro = await mainDoc.copyPages(introDoc, introPageIndices);
    copiedIntro.forEach(p => mainDoc.addPage(p));

    let totalCompositeFilled = 0;
    let totalFilled = 0;
    const masterPages = masterDoc.getPages();
    for (const zeroIdx of manifest.mainPagesToCopy) {
      const pageNum = zeroIdx + 1;
      const srcPage = masterPages[zeroIdx];
      const { width, height } = srcPage.getSize();
      const outPage = mainDoc.addPage([width, height]);
      if (!isFullCustomPage(pageNum)) {
        const embedded = await mainDoc.embedPage(srcPage);
        outPage.drawPage(embedded, { x: 0, y: 0, width, height });
      }
      const counts = renderOverlayPage(
        outPage,
        pageNum,
        phValues,
        formValues,
        mainFonts,
        includeSchedA,
        derivedValues
      );
      totalCompositeFilled += counts.compositeFilled;
      totalFilled += counts.simpleFilled;
    }

    setBusy('Building Written Consent PDF...');
    const wcDoc = await PDFDocument.create();
    const wcFonts = {
      Helvetica:     await wcDoc.embedFont(PDFLib.StandardFonts.Helvetica),
      HelveticaBold: await wcDoc.embedFont(PDFLib.StandardFonts.HelveticaBold),
      TimesRoman:    await wcDoc.embedFont(PDFLib.StandardFonts.TimesRoman),
      TimesBold:     await wcDoc.embedFont(PDFLib.StandardFonts.TimesRomanBold),
    };
    const wcSrcPage = masterPages[manifest.wcPage - 1];
    const wcSize = wcSrcPage.getSize();
    const embeddedWC = await wcDoc.embedPage(wcSrcPage);
    const wcPage = wcDoc.addPage([wcSize.width, wcSize.height]);
    wcPage.drawPage(embeddedWC, { x: 0, y: 0, width: wcSize.width, height: wcSize.height });
    const wcCounts = renderOverlayPage(
      wcPage,
      manifest.wcPage,
      phValues,
      formValues,
      wcFonts,
      includeSchedA,
      derivedValues
    );
    totalCompositeFilled += wcCounts.compositeFilled;
    totalFilled += wcCounts.simpleFilled;

    console.log(`[mca] Rendered ${totalCompositeFilled} composite slots and ${totalFilled} simple placeholders.`);

    // 8. Post-generation verification
    //     Expected count = intro form pages + funder contract pages
    setBusy('Verifying output...');
    const expectedContract = includeSchedA ? funder.expectedPages.withSchedA : funder.expectedPages.withoutSchedA;
    const expectedTotal = cfg.introFormPageCount + expectedContract;
    const actualMain = mainDoc.getPageCount();
    const actualWc = wcDoc.getPageCount();
    if (actualMain !== expectedTotal) {
      throw new Error(`Page count mismatch: main PDF has ${actualMain} pages, expected ${expectedTotal} (= ${cfg.introFormPageCount} intro + ${expectedContract} contract). Refusing to deliver.`);
    }
    if (actualWc !== 1) {
      throw new Error(`Written Consent PDF must be exactly 1 page, got ${actualWc}.`);
    }

    // 9. Save PDFs (do this BEFORE the token leakage check so we can scan)
    setBusy('Saving PDFs...');
    const mainBytes = await mainDoc.save();
    const wcBytes = await wcDoc.save();

    // 10. Runtime token leakage check — refuse to deliver any PDF that
    //     contains raw {{...}} tokens in the text layer. This guards
    //     against any regression in the redaction step or master template
    //     drift. Uses PDF.js to extract text from the saved bytes.
    setBusy('Scanning for token leakage...');
    await assertNoTokenLeakage(mainBytes, 'main contract');
    await assertNoTokenLeakage(wcBytes, 'Written Consent');

    // 11. Trigger downloads

    const safe = sanitize(formValues.business_name || 'Merchant');
    const mainName = `${safe}_MCA_Contract_${funderCode}.pdf`;
    const wcName = `${safe}_Written_Consent_${funderCode}.pdf`;

    triggerDownload(mainBytes, mainName);
    await sleep(300);
    triggerDownload(wcBytes, wcName);

    setBusy('');
    const contractPages = actualMain - cfg.introFormPageCount;
    let msg = `Generated:\n  • ${mainName} (${actualMain} pages = ${cfg.introFormPageCount} intro form + ${contractPages} contract, Schedule A ${includeSchedA ? 'INCLUDED' : 'omitted'})\n  • ${wcName} (1 page)`;
    if (warnings.length) msg += '\n\nWarnings:\n  • ' + warnings.join('\n  • ');
    flashStatus(msg, warnings.length ? 'warn' : 'ok');
  }

  function sanitize(name) {
    return String(name).trim().replace(/[^a-zA-Z0-9]+/g, '_').replace(/^_+|_+$/g, '').substring(0, 80) || 'Merchant';
  }

  function triggerDownload(bytes, filename) {
    const blob = new Blob([bytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  /* ========================================================================
   * UI HELPERS
   * ======================================================================*/
  function setBusy(message) {
    const busy = $('#busy-bar');
    if (!message) { busy.classList.remove('show'); busy.textContent = ''; }
    else { busy.classList.add('show'); busy.textContent = message; }
  }
  function flashStatus(msg, type) {
    const s = $('#status');
    s.className = 'status ' + (type === 'warn' ? 'warn' : type === 'err' ? 'err' : 'ok');
    s.textContent = msg;
  }
  function clearStatus() {
    const s = $('#status'); s.className = 'status'; s.textContent = '';
  }

  /* ========================================================================
   * EVENT WIRING
   * ======================================================================*/
  function wire() {
    $('#funder-select').addEventListener('change', (e) => {
      STATE.currentFunder = e.target.value;
      $('#funder-label').textContent = cfg.FUNDERS[STATE.currentFunder].label;
      autosave();
    });

    $('#btn-generate').addEventListener('click', async () => {
      try { clearStatus(); await generate(); }
      catch (e) { console.error(e); setBusy(''); flashStatus(e.message || String(e), 'err'); }
    });

    $('#btn-fill-sample').addEventListener('click', () => {
      writeForm({ ...cfg.SAMPLE_DATA, funder: STATE.currentFunder });
      autosave();
      flashStatus('Sample data filled.');
    });

    $('#btn-clear').addEventListener('click', () => {
      if (!confirm('Clear all fields? Saved drafts are kept.')) return;
      const blank = {};
      $$('input[data-field], select[data-field]').forEach(el => blank[el.dataset.field] = '');
      writeForm({ ...blank, funder: STATE.currentFunder });
      autosave();
    });

    $('#btn-save-draft').addEventListener('click', () => {
      const name = $('#draft-name').value.trim();
      if (!name) { flashStatus('Give the draft a name first.', 'err'); return; }
      saveDraft(name);
      flashStatus(`Saved draft "${name}".`);
    });

    $('#draft-load-select').addEventListener('change', (e) => {
      const name = e.target.value;
      if (name) loadDraft(name);
      e.target.value = '';
    });

    $('#btn-delete-draft').addEventListener('click', () => {
      const name = $('#draft-name').value.trim();
      if (!name) { flashStatus('Type the draft name to delete.', 'err'); return; }
      const drafts = listDrafts();
      if (!drafts[name]) { flashStatus(`No draft named "${name}".`, 'err'); return; }
      if (!confirm(`Delete draft "${name}"?`)) return;
      deleteDraft(name);
      flashStatus(`Deleted draft "${name}".`);
    });
  }

  /* ========================================================================
   * BOOTSTRAP
   * ======================================================================*/
  async function init() {
    const params = new URLSearchParams(location.search);
    renderForm();
    wire();
    restoreAutosave();
    refreshDraftList();
    const sampleMode = params.get('sample');
    if (sampleMode) {
      const sampleData = sampleMode === 'stress' ? cfg.STRESS_SAMPLE_DATA : cfg.SAMPLE_DATA;
      writeForm({ ...sampleData, funder: STATE.currentFunder });
      autosave();
    }
    loadMasterIfNeeded().then(() => {
      window.MCA_DEBUG_READY = true;
      const totalPlaceholders = Array.from(STATE.coordsByPage.values()).reduce((a, v) => a + v.length, 0);
      console.log(`[mca] Master loaded. ${totalPlaceholders} placeholder coords across ${STATE.coordsByPage.size} pages.`);
      if (params.get('autogen') === '1') {
        setTimeout(() => {
          $('#btn-generate').click();
        }, 250);
      }
    }).catch(e => {
      console.error(e);
      flashStatus('Could not load master: ' + e.message, 'err');
    });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
